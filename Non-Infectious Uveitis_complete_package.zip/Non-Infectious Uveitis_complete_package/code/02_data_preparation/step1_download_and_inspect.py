#!/usr/bin/env python3
"""
Adım 1: Eksik veri setlerini GEOparse ile indirme ve mevcut verileri inceleme
"""
import os
import gzip
import GEOparse
import pandas as pd

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"

# ============================================================
# 1. Mevcut count matrislerini incele
# ============================================================
print("=" * 70)
print("MEVCUT COUNT MATRISLERI INCELENIYOR")
print("=" * 70)

# GSE198533 - Behçet PBMC
f198 = os.path.join(BASE_DIR, "GSE198533", "GSE198533_Raw_gene_counts_matrix.csv.gz")
if os.path.exists(f198):
    df198 = pd.read_csv(f198, compression='gzip', index_col=0)
    print(f"\nGSE198533 (Behcet PBMC): {df198.shape[0]} gen x {df198.shape[1]} ornek")
    print(f"  Ornekler: {list(df198.columns[:5])}...")
    print(f"  Gen ornekleri: {list(df198.index[:5])}")

# GSE205867 - Behçet Nötrofil
f205 = os.path.join(BASE_DIR, "GSE205867", "GSE205867_count_matrix.csv.gz")
if os.path.exists(f205):
    df205 = pd.read_csv(f205, compression='gzip', index_col=0)
    print(f"\nGSE205867 (Behcet Notrofil): {df205.shape[0]} gen x {df205.shape[1]} ornek")
    print(f"  Ornekler: {list(df205.columns[:5])}...")
    print(f"  Gen ornekleri: {list(df205.index[:5])}")

# GSE166663 - VKH FPKM
f166 = os.path.join(BASE_DIR, "GSE166663", "GSE166663_gene_fpkm.txt.gz")
if os.path.exists(f166):
    df166 = pd.read_csv(f166, compression='gzip', sep='\t', index_col=0)
    print(f"\nGSE166663 (VKH Tam Kan): {df166.shape[0]} gen x {df166.shape[1]} ornek")
    print(f"  Ornekler: {list(df166.columns[:5])}...")
    print(f"  Gen ornekleri: {list(df166.index[:5])}")

# GSE155644 - Sarkoidoz
f155 = os.path.join(BASE_DIR, "GSE155644", "GSE155644_ACCESS_mRNA_Count_Matrix_Rounded.txt.gz")
if os.path.exists(f155):
    df155 = pd.read_csv(f155, compression='gzip', sep='\t', index_col=0)
    print(f"\nGSE155644 (Sarkoidoz PBMC): {df155.shape[0]} gen x {df155.shape[1]} ornek")
    print(f"  Ornekler: {list(df155.columns[:5])}...")
    print(f"  Gen ornekleri: {list(df155.index[:5])}")

# ============================================================
# 2. Eksik veri setlerini GEOparse ile indir
# ============================================================
print("\n" + "=" * 70)
print("EKSIK VERI SETLERI INDIRILIYOR (GEOparse)")
print("=" * 70)

missing_datasets = ["GSE194060", "GSE195501", "GSE165254"]

for gse_id in missing_datasets:
    dest_dir = os.path.join(BASE_DIR, gse_id)
    os.makedirs(dest_dir, exist_ok=True)
    
    print(f"\n--- {gse_id} ---")
    try:
        gse = GEOparse.get_GEO(geo=gse_id, destdir=dest_dir, silent=True)
        print(f"  Baslik: {gse.metadata.get('title', ['N/A'])[0][:80]}")
        print(f"  Ornek sayisi: {len(gse.gsms)}")
        
        # Her örneğin metadata'sını çıkar
        sample_info = []
        for gsm_name, gsm in gse.gsms.items():
            info = {
                'sample_id': gsm_name,
                'title': gsm.metadata.get('title', ['N/A'])[0],
                'source': gsm.metadata.get('source_name_ch1', ['N/A'])[0],
            }
            # characteristics_ch1'den hastalık durumunu çıkar
            chars = gsm.metadata.get('characteristics_ch1', [])
            for c in chars:
                if ':' in c:
                    key, val = c.split(':', 1)
                    info[key.strip().lower().replace(' ', '_')] = val.strip()
            
            # Supplementary dosya URL'lerini al
            suppl_files = gsm.metadata.get('supplementary_file_1', [])
            if suppl_files:
                info['suppl_url'] = suppl_files[0]
            
            sample_info.append(info)
        
        # Metadata'yı kaydet
        df_meta = pd.DataFrame(sample_info)
        meta_path = os.path.join(dest_dir, f"{gse_id}_sample_metadata.csv")
        df_meta.to_csv(meta_path, index=False)
        print(f"  Metadata kaydedildi: {meta_path}")
        print(f"  Kolonlar: {list(df_meta.columns)}")
        
        # Supplementary dosya URL'lerini göster
        if 'suppl_url' in df_meta.columns:
            urls = df_meta['suppl_url'].dropna().tolist()
            if urls:
                print(f"  Ornek suppl URL: {urls[0][:100]}...")
                
    except Exception as e:
        print(f"  HATA: {e}")

print("\n" + "=" * 70)
print("TAMAMLANDI")
print("=" * 70)
