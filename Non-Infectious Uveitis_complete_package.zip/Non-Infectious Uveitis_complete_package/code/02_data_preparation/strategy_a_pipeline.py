#!/usr/bin/env python3
"""
Strateji A: GSE194060 + GSE195501 (CD1c+ cDC2)
İkili sınıflandırma: Disease vs Healthy
Ham veri ve ML-ready veri hazırlama
"""
import os
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"
RAW_OUT = "/home/ubuntu/strategy_a_raw_data"
ML_OUT = "/home/ubuntu/strategy_a_ml_ready"
os.makedirs(RAW_OUT, exist_ok=True)
os.makedirs(ML_OUT, exist_ok=True)

# ============================================================
# 1. VERİLERİ YÜKLE
# ============================================================
print("=" * 70)
print("ADIM 1: Verileri yukleme")
print("=" * 70)

# Count matrisleri
df194 = pd.read_csv(os.path.join(BASE_DIR, "GSE194060", "GSE194060_count_matrix.csv.gz"),
                     compression='gzip', index_col=0)
df195 = pd.read_csv(os.path.join(BASE_DIR, "GSE195501", "GSE195501_count_matrix.csv.gz"),
                     compression='gzip', index_col=0)

# Metadata
meta194 = pd.read_csv(os.path.join(BASE_DIR, "GSE194060", "GSE194060_sample_metadata.csv"))
meta195 = pd.read_csv(os.path.join(BASE_DIR, "GSE195501", "GSE195501_sample_metadata.csv"))

print(f"GSE194060: {df194.shape[0]} gen x {df194.shape[1]} ornek")
print(f"GSE195501: {df195.shape[0]} gen x {df195.shape[1]} ornek")

# ============================================================
# 2. HASTALIK ALT TİPLERİNİ DETAYLI İNCELE
# ============================================================
print("\n" + "=" * 70)
print("ADIM 2: Hastalik alt tiplerini inceleme")
print("=" * 70)

print("\n--- GSE194060 Metadata ---")
print(f"Kolonlar: {list(meta194.columns)}")
print(f"\nSource degerleri:")
print(meta194['source'].value_counts().to_string())
if 'subject group' in meta194.columns:
    print(f"\nSubject group degerleri:")
    print(meta194['subject group'].value_counts().to_string())

print("\n--- GSE195501 Metadata ---")
print(f"Kolonlar: {list(meta195.columns)}")
print(f"\nSource degerleri:")
print(meta195['source'].value_counts().to_string())
if 'disease status' in meta195.columns:
    print(f"\nDisease status degerleri:")
    print(meta195['disease status'].value_counts().to_string())

# ============================================================
# 3. ETİKETLEME
# ============================================================
print("\n" + "=" * 70)
print("ADIM 3: Etiketleme")
print("=" * 70)

# GSE194060 etiketleri
labels194 = []
for _, row in meta194.iterrows():
    sid = row['sample_id']
    source = str(row['source']).lower()
    
    if 'healthy' in source or 'blood donor' in source:
        disease_detail = 'Healthy'
        binary = 0
    elif 'hla-b27' in source:
        disease_detail = 'HLA-B27+ AAU'
        binary = 1
    elif 'hla-a29' in source or 'birdshot' in source:
        disease_detail = 'HLA-A29+ Birdshot'
        binary = 1
    elif 'idiopathic' in source or 'intermediate' in source:
        disease_detail = 'Idiopathic Intermediate'
        binary = 1
    else:
        disease_detail = 'Other_Uveitis'
        binary = 1
    
    labels194.append({
        'sample_id': sid,
        'source': row['source'],
        'disease_subtype': disease_detail,
        'binary_label': binary,
        'label_text': 'Disease' if binary == 1 else 'Healthy',
        'gender': row.get('gender', 'NA'),
        'age': row.get('age @ sampling', 'NA'),
        'dataset': 'GSE194060',
        'dataset_role': 'Training',
    })

meta194_full = pd.DataFrame(labels194)

# GSE195501 etiketleri
labels195 = []
for _, row in meta195.iterrows():
    sid = row['sample_id']
    source = str(row['source']).lower()
    
    if 'healthy' in source or 'blood donor' in source:
        disease_detail = 'Healthy'
        binary = 0
    elif 'hla-b27' in source:
        disease_detail = 'HLA-B27+ AAU'
        binary = 1
    elif 'hla-a29' in source or 'birdshot' in source:
        disease_detail = 'HLA-A29+ Birdshot'
        binary = 1
    elif 'idiopathic' in source or 'intermediate' in source:
        disease_detail = 'Idiopathic Intermediate'
        binary = 1
    else:
        disease_detail = 'Other_Uveitis'
        binary = 1
    
    labels195.append({
        'sample_id': sid,
        'source': row['source'],
        'disease_subtype': disease_detail,
        'binary_label': binary,
        'label_text': 'Disease' if binary == 1 else 'Healthy',
        'gender': row.get('Sex', 'NA'),
        'age': row.get('age_at_sampling', 'NA'),
        'dataset': 'GSE195501',
        'dataset_role': 'Test',
    })

meta195_full = pd.DataFrame(labels195)

# Birleşik metadata
meta_all = pd.concat([meta194_full, meta195_full], ignore_index=True)

print("\n--- HASTALIK ALT TİPİ DAĞILIMI ---")
print(meta_all.groupby(['dataset', 'disease_subtype']).size().unstack(fill_value=0).to_string())

print("\n--- İKİLİ ETİKET DAĞILIMI ---")
print(meta_all.groupby(['dataset', 'label_text']).size().unstack(fill_value=0).to_string())

print(f"\nToplam: {len(meta_all)} ornek")
print(f"  Disease: {(meta_all['binary_label']==1).sum()}")
print(f"  Healthy: {(meta_all['binary_label']==0).sum()}")

# ============================================================
# 4. HAM VERİ PAKETİ HAZIRLAMA
# ============================================================
print("\n" + "=" * 70)
print("ADIM 4: Ham veri paketi hazirlama")
print("=" * 70)

# Ham count matrislerini kopyala
df194.to_csv(os.path.join(RAW_OUT, "GSE194060_raw_counts.csv.gz"), compression='gzip')
df195.to_csv(os.path.join(RAW_OUT, "GSE195501_raw_counts.csv.gz"), compression='gzip')

# Metadata
meta194_full.to_csv(os.path.join(RAW_OUT, "GSE194060_metadata.csv"), index=False)
meta195_full.to_csv(os.path.join(RAW_OUT, "GSE195501_metadata.csv"), index=False)
meta_all.to_csv(os.path.join(RAW_OUT, "combined_metadata.csv"), index=False)

print("Ham veri dosyalari kaydedildi.")

# ============================================================
# 5. ML-READY VERİ HAZIRLAMA
# ============================================================
print("\n" + "=" * 70)
print("ADIM 5: ML-ready veri hazirlama")
print("=" * 70)

# Ortak genler
common_genes = sorted(list(set(df194.index).intersection(set(df195.index))))
print(f"Ortak gen sayisi: {len(common_genes)}")

df194_common = df194.loc[common_genes]
df195_common = df195.loc[common_genes]

# log2(CPM+1) normalizasyon
def log2_cpm(df):
    df = df.clip(lower=0)
    lib_sizes = df.sum(axis=0)
    cpm = df.div(lib_sizes, axis=1) * 1e6
    return np.log2(cpm + 1)

df194_norm = log2_cpm(df194_common)
df195_norm = log2_cpm(df195_common)

print(f"GSE194060 normalize: min={df194_norm.values.min():.2f}, max={df194_norm.values.max():.2f}, mean={df194_norm.values.mean():.2f}")
print(f"GSE195501 normalize: min={df195_norm.values.min():.2f}, max={df195_norm.values.max():.2f}, mean={df195_norm.values.mean():.2f}")

# Birleşik matris (örnekler satır, genler sütun)
combined = pd.concat([df194_norm.T, df195_norm.T], axis=0)
print(f"\nBirlesik matris: {combined.shape[0]} ornek x {combined.shape[1]} gen")

# Düşük ifadeli genleri filtrele (en az %10 örnekte CPM > 1 olan genler)
min_samples = int(combined.shape[0] * 0.10)
expressed = (combined > np.log2(1 + 1)).sum(axis=0) >= min_samples
combined_filtered_expr = combined.loc[:, expressed]
print(f"Ifade filtresi sonrasi: {combined_filtered_expr.shape[1]} gen (en az %10 ornekte CPM>1)")

# Varyans filtresi (en yüksek varyanslı %50 gen)
gene_vars = combined_filtered_expr.var(axis=0)
n_top = int(len(gene_vars) * 0.50)
top_genes = gene_vars.nlargest(n_top).index.tolist()
combined_filtered = combined_filtered_expr[top_genes]
print(f"Varyans filtresi sonrasi: {combined_filtered.shape[1]} gen (en yuksek varyansli %50)")

# Eğitim seti (GSE194060)
train_samples = meta194_full['sample_id'].tolist()
train_expr = combined.loc[train_samples]
train_expr_f = combined_filtered.loc[train_samples]
train_meta = meta194_full.copy()

# Test seti (GSE195501)
test_samples = meta195_full['sample_id'].tolist()
test_expr = combined.loc[test_samples]
test_expr_f = combined_filtered.loc[test_samples]
test_meta = meta195_full.copy()

print(f"\nEgitim seti: {train_expr.shape[0]} ornek")
print(f"  Disease: {(train_meta['binary_label']==1).sum()}, Healthy: {(train_meta['binary_label']==0).sum()}")
print(f"Test seti: {test_expr.shape[0]} ornek")
print(f"  Disease: {(test_meta['binary_label']==1).sum()}, Healthy: {(test_meta['binary_label']==0).sum()}")

# Sınıf dengesizliği kontrolü
train_ratio = (train_meta['binary_label']==1).sum() / (train_meta['binary_label']==0).sum()
test_ratio = (test_meta['binary_label']==1).sum() / (test_meta['binary_label']==0).sum()
print(f"\nEgitim Disease/Healthy orani: {train_ratio:.2f}:1")
print(f"Test Disease/Healthy orani: {test_ratio:.2f}:1")

# ============================================================
# 6. ML-READY DOSYALARI KAYDET
# ============================================================
print("\n" + "=" * 70)
print("ADIM 6: ML-ready dosyalari kaydetme")
print("=" * 70)

# Tüm genler versiyonu
combined.to_csv(os.path.join(ML_OUT, "expression_all_genes.csv.gz"), compression='gzip')
train_expr.to_csv(os.path.join(ML_OUT, "train_expression_all_genes.csv.gz"), compression='gzip')
test_expr.to_csv(os.path.join(ML_OUT, "test_expression_all_genes.csv.gz"), compression='gzip')

# Filtrelenmiş genler versiyonu
combined_filtered.to_csv(os.path.join(ML_OUT, "expression_filtered.csv.gz"), compression='gzip')
train_expr_f.to_csv(os.path.join(ML_OUT, "train_expression_filtered.csv.gz"), compression='gzip')
test_expr_f.to_csv(os.path.join(ML_OUT, "test_expression_filtered.csv.gz"), compression='gzip')

# Metadata
meta_all.to_csv(os.path.join(ML_OUT, "sample_metadata.csv"), index=False)
train_meta.to_csv(os.path.join(ML_OUT, "train_metadata.csv"), index=False)
test_meta.to_csv(os.path.join(ML_OUT, "test_metadata.csv"), index=False)

# Gen bilgi dosyası
gene_info = pd.DataFrame({
    'gene_id': common_genes,
    'mean_expression': combined.mean(axis=0).values,
    'variance': combined.var(axis=0).values,
    'expressed_in_pct_samples': ((combined > np.log2(1 + 1)).sum(axis=0) / combined.shape[0] * 100).values,
    'in_filtered_set': [g in top_genes for g in common_genes],
})
gene_info.to_csv(os.path.join(ML_OUT, "gene_info.csv"), index=False)

# Özet istatistikler
summary = {
    'total_samples': len(meta_all),
    'total_genes_common': len(common_genes),
    'filtered_genes': len(top_genes),
    'train_samples': len(train_samples),
    'train_disease': int((train_meta['binary_label']==1).sum()),
    'train_healthy': int((train_meta['binary_label']==0).sum()),
    'test_samples': len(test_samples),
    'test_disease': int((test_meta['binary_label']==1).sum()),
    'test_healthy': int((test_meta['binary_label']==0).sum()),
}
pd.Series(summary).to_csv(os.path.join(ML_OUT, "dataset_summary.csv"), header=['value'])

print("\nML-ready dosyalar kaydedildi.")

# ============================================================
# 7. DOSYA LİSTESİ
# ============================================================
print("\n" + "=" * 70)
print("DOSYA LISTESI")
print("=" * 70)

print("\n--- HAM VERİ ---")
for f in sorted(os.listdir(RAW_OUT)):
    fpath = os.path.join(RAW_OUT, f)
    size = os.path.getsize(fpath)
    if size > 1024*1024:
        print(f"  {f} ({size/(1024*1024):.1f} MB)")
    else:
        print(f"  {f} ({size/1024:.1f} KB)")

print("\n--- ML-READY VERİ ---")
for f in sorted(os.listdir(ML_OUT)):
    fpath = os.path.join(ML_OUT, f)
    size = os.path.getsize(fpath)
    if size > 1024*1024:
        print(f"  {f} ({size/(1024*1024):.1f} MB)")
    else:
        print(f"  {f} ({size/1024:.1f} KB)")

print("\n" + "=" * 70)
print("TAMAMLANDI!")
print("=" * 70)
