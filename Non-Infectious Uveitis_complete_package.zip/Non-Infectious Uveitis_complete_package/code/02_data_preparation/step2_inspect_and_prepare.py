#!/usr/bin/env python3
"""
Adım 2: Tüm veri setlerini inceleme ve yapılarını anlama
"""
import os, gzip, re
import pandas as pd
import numpy as np

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"

print("=" * 70)
print("TUM VERI SETLERINI INCELEME")
print("=" * 70)

# ============================================================
# 1. GSE194060 - Non-infectious uveitis (42 ornek)
# ============================================================
print("\n--- GSE194060 (Non-infectious uveitis, PBMC CD1c+ cDC2) ---")
f = os.path.join(BASE_DIR, "GSE194060", "GSE194060_count_matrix.csv.gz")
df194 = pd.read_csv(f, compression='gzip', index_col=0)
print(f"  Boyut: {df194.shape}")
print(f"  Ilk 5 ornek: {list(df194.columns[:5])}")
print(f"  Ilk 5 gen: {list(df194.index[:5])}")
print(f"  Deger araligi: {df194.values.min()} - {df194.values.max()}")

# Metadata
meta194 = pd.read_csv(os.path.join(BASE_DIR, "GSE194060", "GSE194060_sample_metadata.csv"))
print(f"  Metadata kolonlari: {list(meta194.columns)}")
print(f"  Source degerleri: {meta194['source'].unique()}")

# ============================================================
# 2. GSE195501 - Non-infectious uveitis Replication (36 ornek)
# ============================================================
print("\n--- GSE195501 (Non-infectious uveitis Replication, PBMC CD1c+ cDC2) ---")
f = os.path.join(BASE_DIR, "GSE195501", "GSE195501_count_matrix.csv.gz")
df195 = pd.read_csv(f, compression='gzip', index_col=0)
print(f"  Boyut: {df195.shape}")
print(f"  Ilk 5 ornek: {list(df195.columns[:5])}")
print(f"  Ilk 5 gen: {list(df195.index[:5])}")
print(f"  Deger araligi: {df195.values.min()} - {df195.values.max()}")

meta195 = pd.read_csv(os.path.join(BASE_DIR, "GSE195501", "GSE195501_sample_metadata.csv"))
print(f"  Metadata kolonlari: {list(meta195.columns)}")
print(f"  Source degerleri: {meta195['source'].unique()}")

# ============================================================
# 3. GSE198533 - Behçet PBMC (19 ornek)
# ============================================================
print("\n--- GSE198533 (Behcet PBMC) ---")
f = os.path.join(BASE_DIR, "GSE198533", "GSE198533_Raw_gene_counts_matrix.csv.gz")
df198 = pd.read_csv(f, compression='gzip', index_col=0)
print(f"  Boyut: {df198.shape}")
print(f"  Ilk 5 ornek: {list(df198.columns[:5])}")
print(f"  Ilk 5 gen: {list(df198.index[:5])}")
print(f"  Deger araligi: {df198.values.min()} - {df198.values.max()}")

# ============================================================
# 4. GSE205867 - Behçet Nötrofil (20 ornek)
# ============================================================
print("\n--- GSE205867 (Behcet Notrofil) ---")
f = os.path.join(BASE_DIR, "GSE205867", "GSE205867_count_matrix.csv.gz")
df205 = pd.read_csv(f, compression='gzip', index_col=0)
print(f"  Boyut: {df205.shape}")
print(f"  Ilk 5 ornek: {list(df205.columns[:5])}")
print(f"  Ilk 5 gen: {list(df205.index[:5])}")
print(f"  Deger araligi: {df205.values.min()} - {df205.values.max()}")

# Sample info
f_info = os.path.join(BASE_DIR, "GSE205867", "GSE205867_sample_info.csv.gz")
df205_info = pd.read_csv(f_info, compression='gzip')
print(f"  Sample info: {df205_info.shape}")
print(f"  Kolonlar: {list(df205_info.columns)}")
print(df205_info.head())

# ============================================================
# 5. GSE166663 - VKH Tam Kan (21 ornek)
# ============================================================
print("\n--- GSE166663 (VKH Tam Kan - FPKM) ---")
f = os.path.join(BASE_DIR, "GSE166663", "GSE166663_gene_fpkm.txt.gz")
df166 = pd.read_csv(f, compression='gzip', sep='\t', index_col=0)
print(f"  Boyut: {df166.shape}")
print(f"  Ilk 5 ornek: {list(df166.columns[:5])}")
print(f"  Ilk 5 gen: {list(df166.index[:5])}")
print(f"  Dtypes: {df166.dtypes.value_counts().to_dict()}")
# String sütunları temizle
df166_numeric = df166.select_dtypes(include=[np.number])
print(f"  Numerik boyut: {df166_numeric.shape}")
if df166_numeric.shape[1] > 0:
    print(f"  Deger araligi: {df166_numeric.values.min():.2f} - {df166_numeric.values.max():.2f}")
print(f"  NOT: Bu FPKM verisi (count degil). Normalizasyon farkli olacak.")

# ============================================================
# 6. GSE155644 - Sarkoidoz PBMC (28 ornek)
# ============================================================
print("\n--- GSE155644 (Sarkoidoz PBMC) ---")
f = os.path.join(BASE_DIR, "GSE155644", "GSE155644_ACCESS_mRNA_Count_Matrix_Rounded.txt.gz")
df155 = pd.read_csv(f, compression='gzip', sep='\t', index_col=0)
print(f"  Boyut: {df155.shape}")
print(f"  Ilk 5 ornek: {list(df155.columns[:5])}")
print(f"  Ilk 5 gen: {list(df155.index[:5])}")
print(f"  Deger araligi: {df155.values.min()} - {df155.values.max()}")

# ============================================================
# 7. GSE165254 - Behçet PBMC (25 ornek) - EKSIK
# ============================================================
print("\n--- GSE165254 (Behcet PBMC) ---")
print("  UYARI: Count matrisi mevcut degil (sadece bigWig dosyalari)")
print("  Bu veri seti icin RAW.tar (400MB) indirilmesi gerekiyor")
print("  Alternatif: SRA'dan FASTQ -> alignment -> count")

# ============================================================
# OZET
# ============================================================
print("\n" + "=" * 70)
print("OZET")
print("=" * 70)

datasets_info = [
    ("GSE194060", df194.shape, "Count (int)", "ENSEMBL ID"),
    ("GSE195501", df195.shape, "Count (int)", "ENSEMBL ID"),
    ("GSE198533", df198.shape, "Count (int)", "ENSEMBL ID"),
    ("GSE205867", df205.shape, "Count (int)", "ENSEMBL ID"),
    ("GSE166663", df166.shape, "FPKM (float)", "ENSEMBL ID"),
    ("GSE155644", df155.shape, "Count (int)", "ENSEMBL ID"),
    ("GSE165254", (0, 0), "EKSIK", "-"),
]

print(f"\n{'GSE ID':<12} {'Genler':<10} {'Ornekler':<10} {'Veri Tipi':<15} {'Gen ID Tipi':<15}")
print("-" * 62)
for gse, shape, dtype, gid in datasets_info:
    print(f"{gse:<12} {shape[0]:<10} {shape[1]:<10} {dtype:<15} {gid:<15}")

# Ortak genleri kontrol et
print("\n--- ORTAK GEN ANALIZI ---")
gene_sets = {
    "GSE194060": set(df194.index),
    "GSE195501": set(df195.index),
    "GSE198533": set(df198.index),
    "GSE205867": set(df205.index),
    "GSE166663": set(df166.index),
    "GSE155644": set(df155.index),
}

# Tum veri setlerinin kesisimi
common_genes = gene_sets["GSE194060"]
for name, gset in gene_sets.items():
    common_genes = common_genes.intersection(gset)
    print(f"  {name}: {len(gset)} gen")

print(f"\n  ORTAK GEN SAYISI (tum 6 veri seti): {len(common_genes)}")

# Count-only veri setlerinin kesisimi (FPKM hariç)
count_gene_sets = {k: v for k, v in gene_sets.items() if k != "GSE166663"}
common_count_genes = count_gene_sets["GSE194060"]
for name, gset in count_gene_sets.items():
    common_count_genes = common_count_genes.intersection(gset)
print(f"  ORTAK GEN SAYISI (count-only, 5 veri seti): {len(common_count_genes)}")
