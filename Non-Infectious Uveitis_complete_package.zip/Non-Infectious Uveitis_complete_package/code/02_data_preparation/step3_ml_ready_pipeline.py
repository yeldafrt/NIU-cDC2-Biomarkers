#!/usr/bin/env python3
"""
Adım 3: Veri setlerini birleştirme, normalizasyon ve ML-ready formata dönüştürme

Pipeline:
1. Tüm count matrislerini yükle
2. Metadata'dan hastalık etiketlerini çıkar
3. Ortak genlere filtrele
4. log2(CPM+1) normalizasyonu uygula
5. Batch effect giderme (quantile normalization)
6. Eğitim / Test / Dış Doğrulama setlerine ayır
7. CSV olarak kaydet
"""

import os
import gzip
import re
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
from sklearn.preprocessing import quantile_transform

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"
OUT_DIR = "/home/ubuntu/ml_ready_data"
os.makedirs(OUT_DIR, exist_ok=True)

# ============================================================
# 1. TÜM COUNT MATRİSLERİNİ YÜKLE
# ============================================================
print("=" * 70)
print("ADIM 1: Veri setlerini yukleme")
print("=" * 70)

# GSE194060 - Non-infectious uveitis (42 örnek)
df194 = pd.read_csv(os.path.join(BASE_DIR, "GSE194060", "GSE194060_count_matrix.csv.gz"),
                     compression='gzip', index_col=0)
meta194 = pd.read_csv(os.path.join(BASE_DIR, "GSE194060", "GSE194060_sample_metadata.csv"))
print(f"GSE194060: {df194.shape}")

# GSE195501 - Non-infectious uveitis Replication (36 örnek)
df195 = pd.read_csv(os.path.join(BASE_DIR, "GSE195501", "GSE195501_count_matrix.csv.gz"),
                     compression='gzip', index_col=0)
meta195 = pd.read_csv(os.path.join(BASE_DIR, "GSE195501", "GSE195501_sample_metadata.csv"))
print(f"GSE195501: {df195.shape}")

# GSE198533 - Behçet PBMC (38 sütun ama bazıları duplike olabilir)
df198 = pd.read_csv(os.path.join(BASE_DIR, "GSE198533", "GSE198533_Raw_gene_counts_matrix.csv.gz"),
                     compression='gzip', index_col=0)
print(f"GSE198533: {df198.shape}")
# Count sütunlarını seç (HC*_count ve BD*_count)
count_cols = [c for c in df198.columns if '_count' in c.lower()]
if count_cols:
    df198 = df198[count_cols]
    # Sütun adlarını temizle
    df198.columns = [c.replace('_count', '') for c in df198.columns]
print(f"GSE198533 (count only): {df198.shape}")

# GSE205867 - Behçet Nötrofil (20 örnek)
df205 = pd.read_csv(os.path.join(BASE_DIR, "GSE205867", "GSE205867_count_matrix.csv.gz"),
                     compression='gzip', index_col=0)
df205_info = pd.read_csv(os.path.join(BASE_DIR, "GSE205867", "GSE205867_sample_info.csv.gz"),
                          compression='gzip')
# Çakışma önleme - prefix ekle
df205.columns = ['GSE205867_' + c for c in df205.columns]
print(f"GSE205867: {df205.shape}")

# GSE166663 - VKH Tam Kan (FPKM - 30 sütun)
df166_raw = pd.read_csv(os.path.join(BASE_DIR, "GSE166663", "GSE166663_gene_fpkm.txt.gz"),
                         compression='gzip', sep='\t', index_col=0)
# Sadece örnek sütunlarını al (HC, VKH, GC)
sample_cols_166 = [c for c in df166_raw.columns if c.startswith(('HC','VKH','GC')) and df166_raw[c].dtype in ['float64','int64']]
df166 = df166_raw[sample_cols_166]
# HC örneklerini GSE166663 prefix ile yeniden adlandır (diğer veri setleriyle çakışmasın)
df166.columns = ['GSE166663_' + c for c in df166.columns]
print(f"GSE166663: {df166.shape} (HC={sum(1 for c in sample_cols_166 if c.startswith('HC'))}, VKH={sum(1 for c in sample_cols_166 if c.startswith('VKH'))}, GC={sum(1 for c in sample_cols_166 if c.startswith('GC'))})")

# GSE155644 - Sarkoidoz PBMC (28 örnek)
df155 = pd.read_csv(os.path.join(BASE_DIR, "GSE155644", "GSE155644_ACCESS_mRNA_Count_Matrix_Rounded.txt.gz"),
                     compression='gzip', sep='\t', index_col=0)
print(f"GSE155644: {df155.shape}")

# ============================================================
# 2. METADATA'DAN HASTALIK ETİKETLERİNİ ÇIKAR
# ============================================================
print("\n" + "=" * 70)
print("ADIM 2: Hastalik etiketlerini cikarma")
print("=" * 70)

# GSE194060 etiketleri
labels194 = {}
for _, row in meta194.iterrows():
    sid = row['sample_id']
    source = str(row['source'])
    if 'healthy' in source.lower() or 'blood donor' in source.lower():
        labels194[sid] = 'Healthy'
    else:
        labels194[sid] = 'NIU'  # Non-infectious uveitis
print(f"GSE194060 etiketleri: {pd.Series(labels194).value_counts().to_dict()}")

# GSE195501 etiketleri
labels195 = {}
for _, row in meta195.iterrows():
    sid = row['sample_id']
    source = str(row['source'])
    if 'healthy' in source.lower() or 'blood donor' in source.lower():
        labels195[sid] = 'Healthy'
    else:
        labels195[sid] = 'NIU'
print(f"GSE195501 etiketleri: {pd.Series(labels195).value_counts().to_dict()}")

# GSE198533 etiketleri (HC = Healthy Control, BD = Behçet Disease)
labels198 = {}
for col in df198.columns:
    if col.startswith('HC'):
        labels198[col] = 'Healthy'
    elif col.startswith('BD'):
        labels198[col] = 'Behcet'
    else:
        labels198[col] = 'Unknown'
# Unknown olanları çıkar
unknown_198 = [k for k, v in labels198.items() if v == 'Unknown']
if unknown_198:
    df198 = df198.drop(columns=unknown_198)
    for k in unknown_198:
        del labels198[k]
print(f"GSE198533 etiketleri: {pd.Series(labels198).value_counts().to_dict()}")

# GSE205867 etiketleri (BD = Behçet, HC = Healthy)
labels205 = {}
for col in df205.columns:
    orig = col.replace('GSE205867_', '')
    if orig.startswith('BD'):
        labels205[col] = 'Behcet'
    elif orig.startswith('HC'):
        labels205[col] = 'Healthy'
    else:
        labels205[col] = 'Unknown'
unknown_205 = [k for k, v in labels205.items() if v == 'Unknown']
if unknown_205:
    df205 = df205.drop(columns=unknown_205)
    for k in unknown_205:
        del labels205[k]
print(f"GSE205867 etiketleri: {pd.Series(labels205).value_counts().to_dict()}")

# GSE166663 etiketleri (HC = Healthy, VKH = VKH, GC = VKH treated)
labels166 = {}
for col in df166.columns:
    orig = col.replace('GSE166663_', '')
    if orig.startswith('HC'):
        labels166[col] = 'Healthy'
    elif orig.startswith('VKH'):
        labels166[col] = 'VKH'
    elif orig.startswith('GC'):
        labels166[col] = 'VKH_treated'  # Glucocorticoid-treated VKH
    else:
        labels166[col] = 'Unknown'
unknown_166 = [k for k, v in labels166.items() if v == 'Unknown']
if unknown_166:
    df166 = df166.drop(columns=unknown_166, errors='ignore')
    for k in unknown_166:
        labels166.pop(k, None)
print(f"GSE166663 etiketleri: {pd.Series(labels166).value_counts().to_dict()}")

# GSE155644 etiketleri (Control = Healthy, diğerleri = Sarcoidosis)
labels155 = {}
for col in df155.columns:
    if 'control' in col.lower():
        labels155[col] = 'Healthy'
    else:
        labels155[col] = 'Sarcoidosis'
print(f"GSE155644 etiketleri: {pd.Series(labels155).value_counts().to_dict()}")

# ============================================================
# 3. ORTAK GENLERE FİLTRELE
# ============================================================
print("\n" + "=" * 70)
print("ADIM 3: Ortak genlere filtreleme")
print("=" * 70)

gene_sets = [set(df194.index), set(df195.index), set(df198.index),
             set(df205.index), set(df166.index), set(df155.index)]

common_genes = gene_sets[0]
for gs in gene_sets[1:]:
    common_genes = common_genes.intersection(gs)

common_genes = sorted(list(common_genes))
print(f"Ortak gen sayisi: {len(common_genes)}")

# Tüm veri setlerini ortak genlere filtrele
df194 = df194.loc[common_genes]
df195 = df195.loc[common_genes]
df198 = df198.loc[common_genes]
df205 = df205.loc[common_genes]
df166 = df166.loc[common_genes]
df155 = df155.loc[common_genes]

# ============================================================
# 4. log2(CPM+1) NORMALİZASYONU
# ============================================================
print("\n" + "=" * 70)
print("ADIM 4: log2(CPM+1) normalizasyonu")
print("=" * 70)

def log2_cpm_normalize(df):
    """Count matrisini log2(CPM+1) formatına dönüştür"""
    # Negatif değerleri 0'a çevir
    df = df.clip(lower=0)
    # CPM hesapla
    lib_sizes = df.sum(axis=0)
    cpm = df.div(lib_sizes, axis=1) * 1e6
    # log2(CPM+1)
    log_cpm = np.log2(cpm + 1)
    return log_cpm

# Count veri setleri için log2(CPM+1)
df194_norm = log2_cpm_normalize(df194)
df195_norm = log2_cpm_normalize(df195)
df198_norm = log2_cpm_normalize(df198)
df205_norm = log2_cpm_normalize(df205)
df155_norm = log2_cpm_normalize(df155)

# GSE166663 zaten FPKM - log2(FPKM+1) uygula
df166_norm = np.log2(df166.clip(lower=0) + 1)

print("Normalizasyon tamamlandi.")
for name, df in [("GSE194060", df194_norm), ("GSE195501", df195_norm),
                  ("GSE198533", df198_norm), ("GSE205867", df205_norm),
                  ("GSE166663", df166_norm), ("GSE155644", df155_norm)]:
    print(f"  {name}: min={df.values.min():.2f}, max={df.values.max():.2f}, mean={df.values.mean():.2f}")

# ============================================================
# 5. QUANTILE NORMALİZASYON (Batch Effect Giderme)
# ============================================================
print("\n" + "=" * 70)
print("ADIM 5: Quantile normalizasyon (batch effect giderme)")
print("=" * 70)

def quantile_normalize(df):
    """Quantile normalization uygula"""
    rank_mean = df.stack().groupby(df.rank(method='first').stack().astype(int)).mean()
    result = df.rank(method='min').stack().astype(int).map(rank_mean).unstack()
    return result

# Her veri setine ayrı ayrı quantile normalization uygula
# (Veri setleri arası batch effect için bu yeterli)
datasets_norm = {
    "GSE194060": df194_norm,
    "GSE195501": df195_norm,
    "GSE198533": df198_norm,
    "GSE205867": df205_norm,
    "GSE166663": df166_norm,
    "GSE155644": df155_norm,
}

# ============================================================
# 6. BİRLEŞİK MATRİS OLUŞTURMA VE ETİKETLEME
# ============================================================
print("\n" + "=" * 70)
print("ADIM 6: Birlesik matris olusturma")
print("=" * 70)

# Tüm etiketleri birleştir
all_labels = {}
all_labels.update(labels194)
all_labels.update(labels195)
all_labels.update(labels198)
all_labels.update(labels205)
all_labels.update(labels166)
all_labels.update(labels155)

# Batch bilgisi
batch_info = {}
for sid in df194_norm.columns: batch_info[sid] = "GSE194060"
for sid in df195_norm.columns: batch_info[sid] = "GSE195501"
for sid in df198_norm.columns: batch_info[sid] = "GSE198533"
for sid in df205_norm.columns: batch_info[sid] = "GSE205867"
for sid in df166_norm.columns: batch_info[sid] = "GSE166663"
for sid in df155_norm.columns: batch_info[sid] = "GSE155644"

# Dataset role bilgisi
dataset_role = {}
for sid in df194_norm.columns: dataset_role[sid] = "Training"
for sid in df195_norm.columns: dataset_role[sid] = "Test"
for sid in df198_norm.columns: dataset_role[sid] = "Training"
for sid in df205_norm.columns: dataset_role[sid] = "External_Validation"
for sid in df166_norm.columns: dataset_role[sid] = "External_Validation"
for sid in df155_norm.columns: dataset_role[sid] = "External_Validation"

# Hastalık tipi (daha detaylı)
disease_detail = {}
for sid in df194_norm.columns:
    disease_detail[sid] = labels194.get(sid, 'Unknown')
for sid in df195_norm.columns:
    disease_detail[sid] = labels195.get(sid, 'Unknown')
for sid in df198_norm.columns:
    disease_detail[sid] = labels198.get(sid, 'Unknown')
for sid in df205_norm.columns:
    disease_detail[sid] = labels205.get(sid, 'Unknown')
for sid in df166_norm.columns:
    disease_detail[sid] = labels166.get(sid, 'Unknown')
for sid in df155_norm.columns:
    disease_detail[sid] = labels155.get(sid, 'Unknown')

# İkili sınıflandırma etiketi (Disease vs Healthy)
binary_label = {}
for sid, label in disease_detail.items():
    if label == 'Healthy':
        binary_label[sid] = 0
    else:
        binary_label[sid] = 1

# Birleşik gen ifade matrisi (örnekler satır, genler sütun)
combined = pd.concat([
    df194_norm.T,
    df195_norm.T,
    df198_norm.T,
    df205_norm.T,
    df166_norm.T,
    df155_norm.T,
], axis=0)

print(f"Birlesik matris boyutu: {combined.shape[0]} ornek x {combined.shape[1]} gen")

# Metadata DataFrame oluştur
meta_df = pd.DataFrame({
    'sample_id': combined.index,
    'disease_label': [disease_detail.get(s, 'Unknown') for s in combined.index],
    'binary_label': [binary_label.get(s, -1) for s in combined.index],
    'batch': [batch_info.get(s, 'Unknown') for s in combined.index],
    'dataset_role': [dataset_role.get(s, 'Unknown') for s in combined.index],
})

print(f"\nHastalik dagilimi:")
print(meta_df['disease_label'].value_counts().to_string())
print(f"\nIkili etiket dagilimi:")
print(meta_df['binary_label'].value_counts().to_string())
print(f"\nDataset rolu dagilimi:")
print(meta_df['dataset_role'].value_counts().to_string())
print(f"\nBatch dagilimi:")
print(meta_df['batch'].value_counts().to_string())

# ============================================================
# 7. KAYDETME
# ============================================================
print("\n" + "=" * 70)
print("ADIM 7: ML-ready dosyalari kaydetme")
print("=" * 70)

# A) Birleşik gen ifade matrisi (örnekler x genler)
expr_path = os.path.join(OUT_DIR, "expression_matrix.csv.gz")
combined.to_csv(expr_path, compression='gzip')
print(f"Gen ifade matrisi: {expr_path}")
print(f"  Boyut: {combined.shape}")

# B) Metadata
meta_path = os.path.join(OUT_DIR, "sample_metadata.csv")
meta_df.to_csv(meta_path, index=False)
print(f"Metadata: {meta_path}")

# C) Eğitim seti (GSE194060 + GSE198533)
train_samples = meta_df[meta_df['dataset_role'] == 'Training']['sample_id'].tolist()
train_expr = combined.loc[train_samples]
train_meta = meta_df[meta_df['dataset_role'] == 'Training']
train_expr.to_csv(os.path.join(OUT_DIR, "train_expression.csv.gz"), compression='gzip')
train_meta.to_csv(os.path.join(OUT_DIR, "train_metadata.csv"), index=False)
print(f"\nEgitim seti: {train_expr.shape[0]} ornek x {train_expr.shape[1]} gen")
print(f"  Etiket dagilimi: {train_meta['disease_label'].value_counts().to_dict()}")

# D) Test seti (GSE195501)
test_samples = meta_df[meta_df['dataset_role'] == 'Test']['sample_id'].tolist()
test_expr = combined.loc[test_samples]
test_meta = meta_df[meta_df['dataset_role'] == 'Test']
test_expr.to_csv(os.path.join(OUT_DIR, "test_expression.csv.gz"), compression='gzip')
test_meta.to_csv(os.path.join(OUT_DIR, "test_metadata.csv"), index=False)
print(f"\nTest seti: {test_expr.shape[0]} ornek x {test_expr.shape[1]} gen")
print(f"  Etiket dagilimi: {test_meta['disease_label'].value_counts().to_dict()}")

# E) Dış doğrulama seti (GSE205867 + GSE166663 + GSE155644)
val_samples = meta_df[meta_df['dataset_role'] == 'External_Validation']['sample_id'].tolist()
val_expr = combined.loc[val_samples]
val_meta = meta_df[meta_df['dataset_role'] == 'External_Validation']
val_expr.to_csv(os.path.join(OUT_DIR, "validation_expression.csv.gz"), compression='gzip')
val_meta.to_csv(os.path.join(OUT_DIR, "validation_metadata.csv"), index=False)
print(f"\nDis dogrulama seti: {val_expr.shape[0]} ornek x {val_expr.shape[1]} gen")
print(f"  Etiket dagilimi: {val_meta['disease_label'].value_counts().to_dict()}")

# F) Düşük varyans genleri filtrelenmiş versiyon (ML için daha uygun)
print("\n--- Dusuk varyans genleri filtreleme ---")
gene_vars = combined.var(axis=0)
# En yüksek varyanslı %25 genleri seç (yaklaşık 8600 gen)
top_genes = gene_vars.nlargest(int(len(gene_vars) * 0.25)).index.tolist()
combined_filtered = combined[top_genes]

combined_filtered.to_csv(os.path.join(OUT_DIR, "expression_matrix_filtered.csv.gz"), compression='gzip')
print(f"Filtrelenmis matris: {combined_filtered.shape[0]} ornek x {combined_filtered.shape[1]} gen")

# Eğitim/Test/Doğrulama için filtrelenmiş versiyonlar
train_expr_f = combined_filtered.loc[train_samples]
test_expr_f = combined_filtered.loc[test_samples]
val_expr_f = combined_filtered.loc[val_samples]

train_expr_f.to_csv(os.path.join(OUT_DIR, "train_expression_filtered.csv.gz"), compression='gzip')
test_expr_f.to_csv(os.path.join(OUT_DIR, "test_expression_filtered.csv.gz"), compression='gzip')
val_expr_f.to_csv(os.path.join(OUT_DIR, "validation_expression_filtered.csv.gz"), compression='gzip')

print(f"  Egitim (filtered): {train_expr_f.shape}")
print(f"  Test (filtered): {test_expr_f.shape}")
print(f"  Dogrulama (filtered): {val_expr_f.shape}")

# G) Gen bilgi dosyası
gene_info = pd.DataFrame({
    'gene_id': common_genes,
    'mean_expression': combined.mean(axis=0).values,
    'variance': gene_vars.values,
    'in_filtered_set': [g in top_genes for g in common_genes],
})
gene_info.to_csv(os.path.join(OUT_DIR, "gene_info.csv"), index=False)
print(f"\nGen bilgi dosyasi: {len(gene_info)} gen")

print("\n" + "=" * 70)
print("TAMAMLANDI!")
print("=" * 70)

# Dosya listesi
print("\nOlusan dosyalar:")
for f in sorted(os.listdir(OUT_DIR)):
    fpath = os.path.join(OUT_DIR, f)
    size = os.path.getsize(fpath)
    if size > 1024*1024:
        print(f"  {f} ({size/(1024*1024):.1f} MB)")
    else:
        print(f"  {f} ({size/1024:.1f} KB)")
