#!/usr/bin/env python3
"""
GEO'dan bireysel count dosyalarını indirme ve birleştirme
Series matrix dosyalarından sample URL'lerini çıkarır ve count dosyalarını indirir
"""
import os, gzip, re, subprocess, sys
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"

def extract_sample_info_from_matrix(matrix_path):
    """Series matrix dosyasından örnek bilgilerini çıkar"""
    samples = {}
    current_field = None
    sample_ids = []
    
    with gzip.open(matrix_path, 'rt') as f:
        lines = f.readlines()
    
    # Sample ID'leri al
    for line in lines:
        if line.startswith('!Sample_geo_accession'):
            ids = re.findall(r'"(GSM\d+)"', line)
            sample_ids = ids
            for sid in ids:
                if sid not in samples:
                    samples[sid] = {}
        elif line.startswith('!Sample_title'):
            titles = re.findall(r'"([^"]*)"', line)
            for i, t in enumerate(titles):
                if i < len(sample_ids):
                    samples[sample_ids[i]]['title'] = t
        elif line.startswith('!Sample_source_name_ch1'):
            sources = re.findall(r'"([^"]*)"', line)
            for i, s in enumerate(sources):
                if i < len(sample_ids):
                    samples[sample_ids[i]]['source'] = s
        elif line.startswith('!Sample_characteristics_ch1'):
            chars = re.findall(r'"([^"]*)"', line)
            for i, c in enumerate(chars):
                if i < len(sample_ids):
                    if 'characteristics' not in samples[sample_ids[i]]:
                        samples[sample_ids[i]]['characteristics'] = []
                    samples[sample_ids[i]]['characteristics'].append(c)
        elif line.startswith('!Sample_supplementary_file_1'):
            urls = re.findall(r'"(ftp://[^"]+)"', line)
            for i, u in enumerate(urls):
                if i < len(sample_ids):
                    samples[sample_ids[i]]['suppl_url'] = u
    
    return samples

def download_count_file(gsm_id, url, dest_dir, timeout=120):
    """Bireysel count dosyasını indir"""
    filename = url.split('/')[-1]
    dest_path = os.path.join(dest_dir, filename)
    
    if os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
        return dest_path, True
    
    http_url = url.replace('ftp://ftp.ncbi.nlm.nih.gov', 'https://ftp.ncbi.nlm.nih.gov')
    
    try:
        result = subprocess.run(
            ['wget', '-q', '--no-check-certificate', f'--timeout={timeout}', '--tries=2',
             '-O', dest_path, http_url],
            capture_output=True, text=True, timeout=timeout+30
        )
        if result.returncode == 0 and os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
            return dest_path, True
        else:
            if os.path.exists(dest_path):
                os.remove(dest_path)
            return dest_path, False
    except:
        if os.path.exists(dest_path):
            os.remove(dest_path)
        return dest_path, False

def read_count_file(filepath):
    """Bireysel count dosyasını oku"""
    try:
        if filepath.endswith('.gz'):
            df = pd.read_csv(filepath, compression='gzip', sep='\t', header=None, 
                           names=['gene', 'count'], index_col=0)
        else:
            df = pd.read_csv(filepath, sep='\t', header=None, 
                           names=['gene', 'count'], index_col=0)
        # HTSeq summary satırlarını kaldır
        df = df[~df.index.str.startswith('__')]
        return df['count']
    except Exception as e:
        print(f"    Okuma hatasi: {e}")
        return None

def process_dataset(gse_id):
    """Bir veri seti için tüm count dosyalarını indir ve birleştir"""
    dest_dir = os.path.join(BASE_DIR, gse_id)
    counts_dir = os.path.join(dest_dir, "counts")
    os.makedirs(counts_dir, exist_ok=True)
    
    matrix_path = os.path.join(dest_dir, f"{gse_id}_series_matrix.txt.gz")
    if not os.path.exists(matrix_path):
        print(f"  Series matrix bulunamadi: {matrix_path}")
        return None
    
    # Sample bilgilerini çıkar
    samples = extract_sample_info_from_matrix(matrix_path)
    print(f"  {len(samples)} ornek bulundu")
    
    # Metadata kaydet
    meta_rows = []
    for gsm_id, info in samples.items():
        row = {'sample_id': gsm_id, 'title': info.get('title', ''), 'source': info.get('source', '')}
        chars = info.get('characteristics', [])
        for c in chars:
            if ':' in c:
                k, v = c.split(':', 1)
                row[k.strip()] = v.strip()
        meta_rows.append(row)
    
    df_meta = pd.DataFrame(meta_rows)
    meta_path = os.path.join(dest_dir, f"{gse_id}_sample_metadata.csv")
    df_meta.to_csv(meta_path, index=False)
    print(f"  Metadata kaydedildi: {meta_path}")
    
    # Count dosyalarını indir
    urls_to_download = []
    for gsm_id, info in samples.items():
        url = info.get('suppl_url', '')
        if url and 'NONE' not in url.upper():
            urls_to_download.append((gsm_id, url))
    
    if not urls_to_download:
        print(f"  Supplementary URL bulunamadi!")
        return None
    
    print(f"  {len(urls_to_download)} count dosyasi indirilecek...")
    
    # Sıralı indirme (paralel FTP sorunlu olabilir)
    downloaded = {}
    for i, (gsm_id, url) in enumerate(urls_to_download):
        filepath, success = download_count_file(gsm_id, url, counts_dir)
        if success:
            downloaded[gsm_id] = filepath
            if (i+1) % 10 == 0:
                print(f"    {i+1}/{len(urls_to_download)} indirildi")
        else:
            print(f"    HATA: {gsm_id} indirilemedi")
    
    print(f"  {len(downloaded)}/{len(urls_to_download)} dosya basariyla indirildi")
    
    if not downloaded:
        return None
    
    # Count dosyalarını birleştir
    print(f"  Count matrisi olusturuluyor...")
    count_dict = {}
    for gsm_id, filepath in downloaded.items():
        series = read_count_file(filepath)
        if series is not None:
            # Sample adını title'dan al
            sample_title = samples[gsm_id].get('title', gsm_id)
            count_dict[gsm_id] = series
    
    if count_dict:
        count_matrix = pd.DataFrame(count_dict)
        matrix_out = os.path.join(dest_dir, f"{gse_id}_count_matrix.csv.gz")
        count_matrix.to_csv(matrix_out, compression='gzip')
        print(f"  Count matrisi kaydedildi: {count_matrix.shape[0]} gen x {count_matrix.shape[1]} ornek")
        print(f"  Dosya: {matrix_out}")
        return count_matrix
    
    return None

# Ana işlem
datasets_to_process = ["GSE194060", "GSE195501", "GSE165254"]

for gse_id in datasets_to_process:
    print(f"\n{'='*60}")
    print(f"[{gse_id}]")
    print(f"{'='*60}")
    process_dataset(gse_id)

print(f"\n{'='*60}")
print("TAMAMLANDI")
print(f"{'='*60}")
