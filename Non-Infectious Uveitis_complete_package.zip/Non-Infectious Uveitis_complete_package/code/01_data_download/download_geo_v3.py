#!/usr/bin/env python3
"""
GEO veri setlerini indirme scripti - v3
HTTP üzerinden supplementary dosyalarını indirir
Series matrix + processed count matrislerini alır
"""

import os
import subprocess
import sys

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"

# Her veri seti için HTTP URL'leri (FTP yerine HTTP kullanarak daha hızlı indirme)
datasets = [
    {
        "id": "GSE194060",
        "desc": "Non-infectious uveitis - PBMC CD1c+ cDC2 - Bulk RNA-seq (Egitim Seti)",
        "samples": "42 ornek",
        "disease": "Non-infectious uveitis",
        "tissue": "PBMC (CD1c+ cDC2)",
        "platform": "Illumina NovaSeq 6000",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE194nnn/GSE194060/matrix/GSE194060_series_matrix.txt.gz", "series_matrix"),
        ]
    },
    {
        "id": "GSE195501",
        "desc": "Non-infectious uveitis Replication - PBMC CD1c+ cDC2 - Bulk RNA-seq (Test Seti)",
        "samples": "36 ornek",
        "disease": "Non-infectious uveitis",
        "tissue": "PBMC (CD1c+ cDC2)",
        "platform": "Illumina NextSeq 500",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE195nnn/GSE195501/matrix/GSE195501_series_matrix.txt.gz", "series_matrix"),
        ]
    },
    {
        "id": "GSE198533",
        "desc": "Behcet Hastaligi - PBMC - Bulk RNA-seq (Egitim/Test Seti)",
        "samples": "19 ornek (10 kontrol + 9 BD)",
        "disease": "Behcet Hastaligi",
        "tissue": "PBMC",
        "platform": "Illumina NovaSeq 6000",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE198nnn/GSE198533/matrix/GSE198533_series_matrix.txt.gz", "series_matrix"),
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE198nnn/GSE198533/suppl/GSE198533_Raw_gene_counts_matrix.csv.gz", "count_matrix"),
        ]
    },
    {
        "id": "GSE165254",
        "desc": "Behcet Hastaligi - PBMC - Bulk RNA-seq (Dis Dogrulama)",
        "samples": "25 ornek (13 BD + 12 kontrol)",
        "disease": "Behcet Hastaligi",
        "tissue": "PBMC",
        "platform": "Illumina NextSeq 550",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE165nnn/GSE165254/matrix/GSE165254_series_matrix.txt.gz", "series_matrix"),
        ]
    },
    {
        "id": "GSE205867",
        "desc": "Behcet Hastaligi - Periferik Notrofiller - Bulk RNA-seq (Dis Dogrulama)",
        "samples": "20 ornek",
        "disease": "Behcet Hastaligi",
        "tissue": "Periferik Notrofiller",
        "platform": "Illumina NovaSeq 6000",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE205nnn/GSE205867/matrix/GSE205867_series_matrix.txt.gz", "series_matrix"),
        ]
    },
    {
        "id": "GSE166663",
        "desc": "VKH Sendromu - Tam Kan - Bulk RNA-seq (Dis Dogrulama)",
        "samples": "21 ornek",
        "disease": "Vogt-Koyanagi-Harada Sendromu",
        "tissue": "Tam Kan (Whole Blood)",
        "platform": "Illumina NovaSeq 6000",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE166nnn/GSE166663/matrix/GSE166663_series_matrix.txt.gz", "series_matrix"),
        ]
    },
    {
        "id": "GSE155644",
        "desc": "Sarkoidoz - PBMC - Bulk RNA-seq (Dis Dogrulama)",
        "samples": "28 ornek",
        "disease": "Sarkoidoz",
        "tissue": "PBMC",
        "platform": "Illumina MiSeq",
        "urls": [
            ("https://ftp.ncbi.nlm.nih.gov/geo/series/GSE155nnn/GSE155644/matrix/GSE155644_series_matrix.txt.gz", "series_matrix"),
        ]
    },
]

def download_file(url, dest_path, timeout=180):
    """wget ile dosya indir"""
    if os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
        size_mb = os.path.getsize(dest_path) / (1024*1024)
        print(f"  [ATLA] Zaten mevcut: {os.path.basename(dest_path)} ({size_mb:.2f} MB)")
        return True
    print(f"  [INDIR] {os.path.basename(dest_path)}...")
    try:
        result = subprocess.run(
            ["wget", "-q", "--no-check-certificate", "--timeout=60", "--tries=3", "-O", dest_path, url],
            capture_output=True, text=True, timeout=timeout
        )
        if result.returncode == 0 and os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
            size_mb = os.path.getsize(dest_path) / (1024*1024)
            print(f"  [OK] {os.path.basename(dest_path)} ({size_mb:.2f} MB)")
            return True
        else:
            print(f"  [HATA] Indirilemedi (return code: {result.returncode})")
            if os.path.exists(dest_path):
                os.remove(dest_path)
            return False
    except subprocess.TimeoutExpired:
        print(f"  [TIMEOUT] Zaman asimi - dosya cok buyuk olabilir")
        if os.path.exists(dest_path):
            os.remove(dest_path)
        return False

def main():
    success_count = 0
    fail_count = 0
    
    for ds in datasets:
        gse_id = ds["id"]
        dest_dir = os.path.join(BASE_DIR, gse_id)
        os.makedirs(dest_dir, exist_ok=True)
        
        print(f"\n{'='*60}")
        print(f"[{gse_id}] {ds['desc']}")
        print(f"{'='*60}")
        
        # README oluştur
        readme_path = os.path.join(dest_dir, "README.txt")
        with open(readme_path, "w", encoding="utf-8") as f:
            f.write(f"GEO Accession: {gse_id}\n")
            f.write(f"Aciklama: {ds['desc']}\n")
            f.write(f"Ornek Sayisi: {ds['samples']}\n")
            f.write(f"Hastalik: {ds['disease']}\n")
            f.write(f"Doku/Hucre: {ds['tissue']}\n")
            f.write(f"Platform: {ds['platform']}\n")
            f.write(f"GEO URL: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gse_id}\n")
            f.write(f"\nDosyalar:\n")
        
        for url, ftype in ds["urls"]:
            filename = url.split("/")[-1]
            dest_path = os.path.join(dest_dir, filename)
            if download_file(url, dest_path):
                success_count += 1
                with open(readme_path, "a") as f:
                    f.write(f"  - {filename} ({ftype})\n")
            else:
                fail_count += 1
    
    # Ana README oluştur
    main_readme = os.path.join(BASE_DIR, "README.txt")
    with open(main_readme, "w", encoding="utf-8") as f:
        f.write("=" * 70 + "\n")
        f.write("NON-INFECTIOUS UVEITIS / BEHCET HASTALIGI\n")
        f.write("BULK RNA-SEQ VERI SETLERI HAVUZU\n")
        f.write("=" * 70 + "\n\n")
        f.write("Bu klasor, non-infectious uveitis ve Behcet hastaligi alaninda\n")
        f.write("aciklanabilir yapay zeka (XAI) calismasi icin derlenmis\n")
        f.write("Bulk RNA-seq veri setlerini icerir.\n\n")
        f.write("TOPLAM: 7 veri seti, ~190 ornek\n\n")
        f.write("VERI SETLERI:\n")
        f.write("-" * 70 + "\n")
        for ds in datasets:
            f.write(f"\n{ds['id']}: {ds['desc']}\n")
            f.write(f"  Ornek: {ds['samples']}\n")
            f.write(f"  Hastalik: {ds['disease']}\n")
            f.write(f"  Doku: {ds['tissue']}\n")
            f.write(f"  Platform: {ds['platform']}\n")
            f.write(f"  URL: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={ds['id']}\n")
        f.write("\n" + "-" * 70 + "\n")
        f.write("\nNOT: Series Matrix dosyalari metadata ve (varsa) islenmis gen ifadesi\n")
        f.write("verilerini icerir. RNA-seq veri setlerinde ham sayim matrisleri\n")
        f.write("genellikle ayri supplementary dosyalarda bulunur.\n")
        f.write("Bazi veri setleri icin ham verilere SRA uzerinden erisilebilir.\n")
        f.write("\nONERILEN IS AKISI:\n")
        f.write("1. R'de GEOquery paketi ile verileri yukleyin\n")
        f.write("2. ComBat-Seq ile batch effect giderin\n")
        f.write("3. DESeq2 ile normalizasyon yapin\n")
        f.write("4. ML modeli egitimi ve SHAP analizi\n")
    
    print(f"\n{'='*60}")
    print(f"OZET: {success_count} basarili, {fail_count} basarisiz")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
