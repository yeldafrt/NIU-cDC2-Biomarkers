#!/usr/bin/env python3
"""
Series matrix dosyalarından supplementary dosya URL'lerini çıkar ve indir
"""
import os, gzip, re, subprocess

BASE_DIR = "/home/ubuntu/uveitis_behcet_datasets"

# Her veri seti klasörünü tara
for gse_dir in sorted(os.listdir(BASE_DIR)):
    full_dir = os.path.join(BASE_DIR, gse_dir)
    if not os.path.isdir(full_dir) or not gse_dir.startswith("GSE"):
        continue
    
    matrix_file = os.path.join(full_dir, f"{gse_dir}_series_matrix.txt.gz")
    if not os.path.exists(matrix_file):
        continue
    
    print(f"\n=== {gse_dir} ===")
    
    # Supplementary URL'leri çıkar
    suppl_urls = []
    with gzip.open(matrix_file, 'rt') as f:
        for line in f:
            if line.startswith("!Series_supplementary_file"):
                urls = re.findall(r'ftp://[^\s"]+', line)
                suppl_urls.extend(urls)
    
    if not suppl_urls:
        print("  Supplementary dosya bulunamadi (veriler SRA'da)")
        continue
    
    for url in suppl_urls:
        filename = url.split("/")[-1]
        dest_path = os.path.join(full_dir, filename)
        
        # RAW.tar dosyalarını atla (çok büyük)
        if filename.endswith("_RAW.tar"):
            print(f"  [ATLA] {filename} (RAW tar - cok buyuk)")
            continue
        
        if os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
            size_mb = os.path.getsize(dest_path) / (1024*1024)
            print(f"  [MEVCUT] {filename} ({size_mb:.2f} MB)")
            continue
        
        # FTP URL'yi HTTP'ye çevir
        http_url = url.replace("ftp://ftp.ncbi.nlm.nih.gov", "https://ftp.ncbi.nlm.nih.gov")
        
        print(f"  [INDIR] {filename}...")
        try:
            result = subprocess.run(
                ["wget", "-q", "--no-check-certificate", "--timeout=120", "--tries=3", 
                 "-O", dest_path, http_url],
                capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0 and os.path.exists(dest_path) and os.path.getsize(dest_path) > 100:
                size_mb = os.path.getsize(dest_path) / (1024*1024)
                print(f"  [OK] {filename} ({size_mb:.2f} MB)")
            else:
                print(f"  [HATA] Indirilemedi")
                if os.path.exists(dest_path):
                    os.remove(dest_path)
        except subprocess.TimeoutExpired:
            print(f"  [TIMEOUT] {filename}")
            if os.path.exists(dest_path):
                os.remove(dest_path)

# Dosya durumunu özetle
print(f"\n{'='*60}")
print("MEVCUT DOSYALAR:")
print(f"{'='*60}")
for gse_dir in sorted(os.listdir(BASE_DIR)):
    full_dir = os.path.join(BASE_DIR, gse_dir)
    if not os.path.isdir(full_dir) or not gse_dir.startswith("GSE"):
        continue
    print(f"\n{gse_dir}/")
    for f in sorted(os.listdir(full_dir)):
        fpath = os.path.join(full_dir, f)
        size = os.path.getsize(fpath)
        if size > 1024*1024:
            print(f"  {f} ({size/(1024*1024):.2f} MB)")
        else:
            print(f"  {f} ({size} bytes)")
