#!/usr/bin/env python3
"""
Nested Cross-Validation Analysis
=================================
Reviewer concern: "a nested cross-validation framework should be used.
Without nesting, the reported performance may be overly optimistic."

This script implements a proper nested CV and compares it with the
original (non-nested) CV to quantify any optimism bias.

Architecture:
  - Outer loop: 5-fold StratifiedKFold (performance estimation)
  - Inner loop: 5-fold StratifiedKFold (hyperparameter tuning)
  - Same pipeline: SelectKBest + StandardScaler + LogisticRegression
  - Same search space: k ∈ {5,10,15,20,25,30,40,50,75,100}, C ∈ {0.001,...,1.0}
"""

import os, json, warnings
import numpy as np
import pandas as pd
from scipy import stats
warnings.filterwarnings('ignore')
np.random.seed(42)

from sklearn.model_selection import StratifiedKFold, cross_validate, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import (roc_auc_score, accuracy_score, f1_score,
                             recall_score, precision_score, make_scorer)

OUT = "/home/ubuntu/nested_cv_results"
os.makedirs(OUT, exist_ok=True)

# ============================================================
# 1. DATA LOADING (same as original pipeline)
# ============================================================
print("=" * 70)
print("NESTED CV ANALYSIS")
print("=" * 70)

RAW_DIR = "/home/ubuntu/strategy_a_ml_ready/strategy_a_raw_data"

df194 = pd.read_csv(f"{RAW_DIR}/GSE194060_raw_counts.csv.gz", compression='gzip', index_col=0)
df195 = pd.read_csv(f"{RAW_DIR}/GSE195501_raw_counts.csv.gz", compression='gzip', index_col=0)
meta194 = pd.read_csv(f"{RAW_DIR}/GSE194060_metadata.csv")
meta195 = pd.read_csv(f"{RAW_DIR}/GSE195501_metadata.csv")

common_genes = sorted(list(set(df194.index) & set(df195.index)))
df194 = df194.loc[common_genes]
df195 = df195.loc[common_genes]

def log2_cpm(df):
    df = df.clip(lower=0)
    lib_sizes = df.sum(axis=0)
    cpm = df.div(lib_sizes, axis=1) * 1e6
    return np.log2(cpm + 1)

df194_norm = log2_cpm(df194).T
df195_norm = log2_cpm(df195).T

X_combined = pd.concat([df194_norm, df195_norm], axis=0)
meta_combined = pd.concat([meta194, meta195], axis=0, ignore_index=True)
meta_combined['batch'] = ['GSE194060'] * len(meta194) + ['GSE195501'] * len(meta195)

y_all = meta_combined['binary_label'].values
batches = meta_combined['batch'].values
feature_names = X_combined.columns.tolist()

print(f"Combined data: {X_combined.shape}")

# ============================================================
# 2. TRAIN/TEST SPLIT (same as original)
# ============================================================
from sklearn.model_selection import train_test_split

stratify_labels = np.array([f"{y}_{b}" for y, b in zip(y_all, batches)])
X_train_raw, X_test_raw, y_train, y_test, idx_train, idx_test = train_test_split(
    X_combined.values, y_all, np.arange(len(y_all)),
    test_size=0.2, stratify=stratify_labels, random_state=42
)
batch_train = batches[idx_train]
batch_test = batches[idx_test]

print(f"Train: {X_train_raw.shape}, Test: {X_test_raw.shape}")

# ============================================================
# 3. BATCH CORRECTION (train-only, same as original)
# ============================================================
batch_train_binary = (batch_train == 'GSE195501').astype(float)
batch_test_binary = (batch_test == 'GSE195501').astype(float)

X_train_corrected = X_train_raw.copy()
X_test_corrected = X_test_raw.copy()

for g in range(X_train_raw.shape[1]):
    y_gene_train = X_train_raw[:, g]
    X_design_train = np.column_stack([np.ones(len(y_gene_train)), batch_train_binary])
    beta = np.linalg.lstsq(X_design_train, y_gene_train, rcond=None)[0]
    X_train_corrected[:, g] = y_gene_train - beta[1] * batch_train_binary
    X_test_corrected[:, g] = X_test_raw[:, g] - beta[1] * batch_test_binary

print("Batch correction done.")

# ============================================================
# 4. VARIANCE FILTER (train-only, same as original)
# ============================================================
min_samples = int(X_train_corrected.shape[0] * 0.10)
expressed_mask = (X_train_corrected > np.log2(1 + 1)).sum(axis=0) >= min_samples
train_vars = X_train_corrected[:, expressed_mask].var(axis=0)
n_top = int(len(train_vars) * 0.50)
top_var_idx = np.argsort(train_vars)[::-1][:n_top]
expressed_indices = np.where(expressed_mask)[0]
selected_gene_indices = expressed_indices[top_var_idx]

X_train = X_train_corrected[:, selected_gene_indices]
X_test = X_test_corrected[:, selected_gene_indices]

print(f"After variance filter: {X_train.shape[1]} genes")

# ============================================================
# 5. NESTED CROSS-VALIDATION
# ============================================================
print("\n" + "=" * 70)
print("NESTED CV (outer=5-fold, inner=5-fold)")
print("=" * 70)

# Search space (same as original grid search)
param_grid = {
    'selector__k': [5, 10, 15, 20, 25, 30, 40, 50, 75, 100],
    'clf__C': [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0]
}

# Filter k values that exceed feature count
param_grid['selector__k'] = [k for k in param_grid['selector__k'] if k <= X_train.shape[1]]

outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
inner_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

nested_outer_scores = []
nested_best_params_per_fold = []
non_nested_scores = []

pipe = Pipeline([
    ('selector', SelectKBest(f_classif)),
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression(penalty='l2', solver='lbfgs',
                               max_iter=10000, class_weight='balanced', random_state=42))
])

print("\nRunning nested CV...")
fold_num = 0
for train_idx, val_idx in outer_cv.split(X_train, y_train):
    fold_num += 1
    X_outer_train, X_outer_val = X_train[train_idx], X_train[val_idx]
    y_outer_train, y_outer_val = y_train[train_idx], y_train[val_idx]
    
    # Inner loop: GridSearchCV for hyperparameter tuning
    grid_search = GridSearchCV(
        pipe, param_grid, cv=inner_cv, scoring='roc_auc',
        n_jobs=-1, refit=True
    )
    grid_search.fit(X_outer_train, y_outer_train)
    
    # Evaluate on outer validation fold with best params from inner loop
    val_proba = grid_search.predict_proba(X_outer_val)[:, 1]
    val_auc = roc_auc_score(y_outer_val, val_proba)
    val_pred = grid_search.predict(X_outer_val)
    val_acc = accuracy_score(y_outer_val, val_pred)
    val_f1 = f1_score(y_outer_val, val_pred, zero_division=0)
    val_recall = recall_score(y_outer_val, val_pred, zero_division=0)
    
    best_k = grid_search.best_params_['selector__k']
    best_C = grid_search.best_params_['clf__C']
    
    nested_outer_scores.append({
        'fold': fold_num,
        'auc': val_auc,
        'accuracy': val_acc,
        'f1': val_f1,
        'recall': val_recall,
        'best_k': best_k,
        'best_C': best_C,
        'inner_best_score': grid_search.best_score_
    })
    
    print(f"  Outer Fold {fold_num}: AUC={val_auc:.4f}, Acc={val_acc:.4f}, "
          f"Best k={best_k}, C={best_C}, Inner AUC={grid_search.best_score_:.4f}")

# ============================================================
# 6. NON-NESTED CV (original approach for comparison)
# ============================================================
print("\nRunning non-nested CV (original approach)...")

# Original: fixed k=20, C=0.001
pipe_fixed = Pipeline([
    ('selector', SelectKBest(f_classif, k=20)),
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression(C=0.001, penalty='l2', solver='lbfgs',
                               max_iter=10000, class_weight='balanced', random_state=42))
])

cv_results_fixed = cross_validate(
    pipe_fixed, X_train, y_train, cv=outer_cv,
    scoring=['roc_auc', 'accuracy', 'f1', 'recall'],
    return_train_score=True, n_jobs=-1
)

print(f"  Non-nested CV AUC: {cv_results_fixed['test_roc_auc'].mean():.4f} "
      f"± {cv_results_fixed['test_roc_auc'].std():.4f}")

# ============================================================
# 7. NON-NESTED CV WITH GRID SEARCH (to measure optimism)
# ============================================================
print("\nRunning non-nested GridSearchCV (to measure optimism)...")

grid_search_full = GridSearchCV(
    pipe, param_grid, cv=outer_cv, scoring='roc_auc',
    n_jobs=-1, refit=True
)
grid_search_full.fit(X_train, y_train)

non_nested_grid_auc = grid_search_full.best_score_
non_nested_grid_params = grid_search_full.best_params_

print(f"  Non-nested GridSearchCV best AUC: {non_nested_grid_auc:.4f}")
print(f"  Non-nested GridSearchCV best params: {non_nested_grid_params}")

# ============================================================
# 8. TEST SET EVALUATION (with nested CV best params)
# ============================================================
print("\n" + "=" * 70)
print("TEST SET EVALUATION")
print("=" * 70)

# Find the most commonly selected hyperparameters from nested CV
nested_df = pd.DataFrame(nested_outer_scores)
most_common_k = int(nested_df['best_k'].mode()[0])
most_common_C = float(nested_df['best_C'].mode()[0])

print(f"\nNested CV most common params: k={most_common_k}, C={most_common_C}")
print(f"Original pipeline params: k=20, C=0.001")

# Test with original params (k=20, C=0.001)
pipe_original = Pipeline([
    ('selector', SelectKBest(f_classif, k=20)),
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression(C=0.001, penalty='l2', solver='lbfgs',
                               max_iter=10000, class_weight='balanced', random_state=42))
])
pipe_original.fit(X_train, y_train)
y_test_proba_orig = pipe_original.predict_proba(X_test)[:, 1]
y_test_pred_orig = pipe_original.predict(X_test)
test_auc_orig = roc_auc_score(y_test, y_test_proba_orig)
test_acc_orig = accuracy_score(y_test, y_test_pred_orig)
test_f1_orig = f1_score(y_test, y_test_pred_orig)
test_recall_orig = recall_score(y_test, y_test_pred_orig)

print(f"\nOriginal (k=20, C=0.001) Test: AUC={test_auc_orig:.4f}, "
      f"Acc={test_acc_orig:.4f}, F1={test_f1_orig:.4f}, Recall={test_recall_orig:.4f}")

# Test with nested CV consensus params
pipe_nested = Pipeline([
    ('selector', SelectKBest(f_classif, k=most_common_k)),
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression(C=most_common_C, penalty='l2', solver='lbfgs',
                               max_iter=10000, class_weight='balanced', random_state=42))
])
pipe_nested.fit(X_train, y_train)
y_test_proba_nested = pipe_nested.predict_proba(X_test)[:, 1]
y_test_pred_nested = pipe_nested.predict(X_test)
test_auc_nested = roc_auc_score(y_test, y_test_proba_nested)
test_acc_nested = accuracy_score(y_test, y_test_pred_nested)
test_f1_nested = f1_score(y_test, y_test_pred_nested)
test_recall_nested = recall_score(y_test, y_test_pred_nested)

print(f"Nested CV consensus (k={most_common_k}, C={most_common_C}) Test: AUC={test_auc_nested:.4f}, "
      f"Acc={test_acc_nested:.4f}, F1={test_f1_nested:.4f}, Recall={test_recall_nested:.4f}")

# ============================================================
# 9. COMPILE RESULTS
# ============================================================
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)

nested_auc_mean = nested_df['auc'].mean()
nested_auc_std = nested_df['auc'].std(ddof=0)
non_nested_auc_mean = cv_results_fixed['test_roc_auc'].mean()
non_nested_auc_std = cv_results_fixed['test_roc_auc'].std()
optimism = non_nested_grid_auc - nested_auc_mean

print(f"\nNested CV AUC:           {nested_auc_mean:.4f} ± {nested_auc_std:.4f}")
print(f"Non-nested CV AUC (fixed): {non_nested_auc_mean:.4f} ± {non_nested_auc_std:.4f}")
print(f"Non-nested GridSearch AUC: {non_nested_grid_auc:.4f}")
print(f"Optimism bias:           {optimism:.4f}")
print(f"\nTest AUC (original):     {test_auc_orig:.4f}")
print(f"Test AUC (nested):       {test_auc_nested:.4f}")

# Per-fold details
print("\nPer-fold nested CV details:")
for _, row in nested_df.iterrows():
    print(f"  Fold {int(row['fold'])}: AUC={row['auc']:.4f}, k={int(row['best_k'])}, "
          f"C={row['best_C']}, Inner AUC={row['inner_best_score']:.4f}")

# Save all results
results = {
    'nested_cv': {
        'mean_auc': float(nested_auc_mean),
        'std_auc': float(nested_auc_std),
        'mean_accuracy': float(nested_df['accuracy'].mean()),
        'mean_f1': float(nested_df['f1'].mean()),
        'mean_recall': float(nested_df['recall'].mean()),
        'per_fold': nested_outer_scores,
        'consensus_k': most_common_k,
        'consensus_C': most_common_C,
    },
    'non_nested_cv_fixed': {
        'mean_auc': float(non_nested_auc_mean),
        'std_auc': float(non_nested_auc_std),
        'params': {'k': 20, 'C': 0.001},
    },
    'non_nested_gridsearch': {
        'best_auc': float(non_nested_grid_auc),
        'best_params': {k: (int(v) if isinstance(v, (int, np.integer)) else float(v)) 
                       for k, v in non_nested_grid_params.items()},
    },
    'optimism_bias': float(optimism),
    'test_set': {
        'original_params': {
            'k': 20, 'C': 0.001,
            'auc': float(test_auc_orig),
            'accuracy': float(test_acc_orig),
            'f1': float(test_f1_orig),
            'recall': float(test_recall_orig),
        },
        'nested_consensus_params': {
            'k': most_common_k, 'C': float(most_common_C),
            'auc': float(test_auc_nested),
            'accuracy': float(test_acc_nested),
            'f1': float(test_f1_nested),
            'recall': float(test_recall_nested),
        }
    }
}

with open(f"{OUT}/nested_cv_comprehensive_results.json", 'w') as f:
    json.dump(results, f, indent=2)

nested_df.to_csv(f"{OUT}/nested_cv_per_fold_results.csv", index=False)

print(f"\nResults saved to {OUT}/")
print("DONE.")
