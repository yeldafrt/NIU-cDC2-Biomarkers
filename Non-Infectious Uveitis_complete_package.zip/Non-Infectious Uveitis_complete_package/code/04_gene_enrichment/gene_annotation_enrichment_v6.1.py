#!/usr/bin/env python3
"""
ENSEMBL ID → Gen Sembolü çevirme ve Pathway/GO Enrichment Analizi
v6.1 pipeline'ın seçtiği 20 gen için kapsamlı biyolojik yorum
"""
import os, json, warnings
import numpy as np
import pandas as pd
import mygene
import gseapy as gp
warnings.filterwarnings('ignore')

OUT = "/home/ubuntu/ml_results_v6/gene_enrichment_results"
os.makedirs(OUT, exist_ok=True)

# ============================================================
# 1. ENSEMBL ID → GEN SEMBOLÜ ÇEVİRME
# ============================================================
print("=" * 70)
print("ADIM 1: ENSEMBL ID → Gen Sembolü Çevirme (v6.1 - 20 gen)")
print("=" * 70)

# v6.1 seçilen 20 gen
selected_ids = np.load("/home/ubuntu/ml_results_v6/npy/selected_features.npy", allow_pickle=True).tolist()

# SHAP importance bilgisi
shap_df = pd.read_csv("/home/ubuntu/ml_results_v6/csv/shap_feature_importance.csv")

# mygene ile çevirme
mg = mygene.MyGeneInfo()

# Versiyon numarasını kaldır (ENSG00000196664.12 → ENSG00000196664)
clean_ids = [g.split('.')[0] for g in selected_ids]

print(f"  {len(clean_ids)} gen sorgulanıyor...")
results = mg.querymany(clean_ids, scopes='ensembl.gene', 
                        fields='symbol,name,summary,entrezgene,type_of_gene,genomic_pos',
                        species='human', returnall=True)

# Sonuçları DataFrame'e çevir
gene_map = {}
gene_details = []
for hit in results['out']:
    query = hit.get('query', '')
    symbol = hit.get('symbol', 'N/A')
    name = hit.get('name', 'N/A')
    entrez = hit.get('entrezgene', 'N/A')
    gene_type = hit.get('type_of_gene', 'N/A')
    summary = hit.get('summary', 'N/A')
    
    # Genomic position
    gpos = hit.get('genomic_pos', {})
    if isinstance(gpos, list):
        gpos = gpos[0]
    chrom = gpos.get('chr', 'N/A') if isinstance(gpos, dict) else 'N/A'
    
    gene_map[query] = symbol
    gene_details.append({
        'ensembl_id': query,
        'symbol': symbol,
        'full_name': name,
        'entrez_id': entrez,
        'gene_type': gene_type,
        'chromosome': chrom,
        'summary': summary[:200] + '...' if isinstance(summary, str) and len(summary) > 200 else summary
    })

gene_details_df = pd.DataFrame(gene_details)
print(f"  Başarıyla çevrilen: {sum(1 for v in gene_map.values() if v != 'N/A')}/{len(clean_ids)}")

# Bulunamayan genleri kontrol et
not_found = [g for g in clean_ids if gene_map.get(g, 'N/A') == 'N/A']
if not_found:
    print(f"  Bulunamayan: {not_found}")

# SHAP df'ye gen sembolü ekle
shap_df['ensembl_clean'] = shap_df['feature'].apply(lambda x: x.split('.')[0])
shap_df['gene_symbol'] = shap_df['ensembl_clean'].map(gene_map).fillna('N/A')

# Birleşik tablo oluştur
merged = shap_df.copy()
merged = merged.merge(gene_details_df[['ensembl_id', 'full_name', 'entrez_id', 'gene_type', 'chromosome']], 
                       left_on='ensembl_clean', right_on='ensembl_id', how='left')
merged = merged.sort_values('shap_importance', ascending=False)

# Kaydet
gene_details_df.to_csv(f"{OUT}/gene_annotation_full.csv", index=False)
merged.to_csv(f"{OUT}/genes_20_annotated_with_importance.csv", index=False)

# Özet tablo (makale için)
summary_table = merged[['gene_symbol', 'ensembl_clean', 'full_name', 'shap_importance', 
                         'coefficient', 'direction', 'chromosome']].copy()
summary_table.columns = ['Gene Symbol', 'ENSEMBL ID', 'Full Name', 'SHAP Importance', 
                          'LR Coefficient', 'Direction', 'Chromosome']
summary_table.to_csv(f"{OUT}/table_for_paper_20genes.csv", index=False)

print("\n  20 Gen (SHAP sırasıyla):")
for i, row in summary_table.iterrows():
    print(f"    {row['Gene Symbol']:12s} | SHAP={row['SHAP Importance']:.4f} | Coef={row['LR Coefficient']:+.4f} | {row['Direction']} | {str(row['Full Name'])[:50]}")

# ============================================================
# 2. TÜM 8767 GEN İÇİN DE ÇEVİRME
# ============================================================
print("\n" + "=" * 70)
print("ADIM 2: Tüm 8767 gen için ENSEMBL → Sembol çevirme")
print("=" * 70)

all_features = np.load("/home/ubuntu/ml_results_v6/npy/feature_names.npy", allow_pickle=True)
all_clean = [g.split('.')[0] for g in all_features]

# Batch halinde sorgula (API limiti)
batch_size = 1000
all_gene_map = {}
for i in range(0, len(all_clean), batch_size):
    batch = all_clean[i:i+batch_size]
    print(f"  Batch {i//batch_size + 1}/{(len(all_clean)-1)//batch_size + 1} ({len(batch)} gen)...")
    res = mg.querymany(batch, scopes='ensembl.gene', fields='symbol,name,entrezgene',
                        species='human', returnall=True)
    for hit in res['out']:
        q = hit.get('query', '')
        s = hit.get('symbol', 'N/A')
        all_gene_map[q] = s

all_gene_df = pd.DataFrame([
    {'ensembl_id': eid, 'gene_symbol': all_gene_map.get(eid, 'N/A')}
    for eid in all_clean
])
all_gene_df.to_csv(f"{OUT}/all_8767_genes_annotated.csv", index=False)
mapped = sum(1 for v in all_gene_map.values() if v != 'N/A')
print(f"  Toplam: {len(all_clean)}, Çevrilen: {mapped}, Bulunamayan: {len(all_clean)-mapped}")

# ============================================================
# 3. PATHWAY / GO ENRICHMENT ANALİZİ
# ============================================================
print("\n" + "=" * 70)
print("ADIM 3: Pathway / GO Enrichment Analizi (20 gen)")
print("=" * 70)

# Seçilen 20 genin sembollerini al (N/A olmayanlar)
gene_symbols_20 = [gene_map[g] for g in clean_ids if gene_map.get(g, 'N/A') != 'N/A']
print(f"  Enrichment için kullanılan gen sayısı: {len(gene_symbols_20)}")
print(f"  Genler: {', '.join(gene_symbols_20)}")

# Disease/Healthy yönüne göre ayır
disease_genes = []
healthy_genes = []
for _, row in merged.iterrows():
    sym = row.get('gene_symbol', 'N/A')
    if sym == 'N/A': continue
    if row.get('direction', '') == 'Disease_up':
        disease_genes.append(sym)
    else:
        healthy_genes.append(sym)

print(f"  Disease-up genler ({len(disease_genes)}): {', '.join(disease_genes)}")
print(f"  Healthy-up genler ({len(healthy_genes)}): {', '.join(healthy_genes)}")

# Enrichment analizi fonksiyonu
def run_enrichment(gene_list, label, gene_sets_list):
    results_all = {}
    for gs_name in gene_sets_list:
        try:
            enr = gp.enrichr(gene_list=gene_list,
                            gene_sets=gs_name,
                            organism='human',
                            outdir=None,
                            no_plot=True,
                            cutoff=0.05)
            if enr.results is not None and len(enr.results) > 0:
                sig = enr.results[enr.results['Adjusted P-value'] < 0.05]
                results_all[gs_name] = enr.results
                if len(sig) > 0:
                    print(f"    {gs_name}: {len(sig)} anlamlı terim (p_adj < 0.05)")
                else:
                    print(f"    {gs_name}: anlamlı terim yok (en düşük p_adj={enr.results['Adjusted P-value'].min():.4f})")
            else:
                print(f"    {gs_name}: sonuç yok")
        except Exception as e:
            print(f"    {gs_name}: HATA - {str(e)[:80]}")
    return results_all

# Kullanılacak gen seti kütüphaneleri
gene_set_libs = [
    'GO_Biological_Process_2023',
    'GO_Molecular_Function_2023', 
    'GO_Cellular_Component_2023',
    'KEGG_2021_Human',
    'Reactome_2022',
    'WikiPathway_2023_Human',
    'MSigDB_Hallmark_2020',
    'BioPlanet_2019',
    'Immune_Cell_Signature_Atlas',
]

# A) Tüm 20 gen
print("\n  --- Tüm 20 gen ---")
all_results = run_enrichment(gene_symbols_20, 'all_20', gene_set_libs)

# B) Disease-up genler
disease_results = {}
if len(disease_genes) >= 3:
    print(f"\n  --- Disease-up genler ({len(disease_genes)}) ---")
    disease_results = run_enrichment(disease_genes, 'disease_up', gene_set_libs)

# C) Healthy-up genler
healthy_results = {}
if len(healthy_genes) >= 3:
    print(f"\n  --- Healthy-up genler ({len(healthy_genes)}) ---")
    healthy_results = run_enrichment(healthy_genes, 'healthy_up', gene_set_libs)

# ============================================================
# 4. SONUÇLARI KAYDET
# ============================================================
print("\n" + "=" * 70)
print("ADIM 4: Sonuçları Kaydetme")
print("=" * 70)

enrichment_dir = f"{OUT}/enrichment"
os.makedirs(enrichment_dir, exist_ok=True)

# Tüm 20 gen sonuçları
all_enrichment_combined = []
for gs_name, df in all_results.items():
    df_copy = df.copy()
    df_copy['gene_set_library'] = gs_name
    df_copy['analysis'] = 'all_20_genes'
    all_enrichment_combined.append(df_copy)
    df.to_csv(f"{enrichment_dir}/all20_{gs_name}.csv", index=False)

# Disease-up sonuçları
if disease_results:
    for gs_name, df in disease_results.items():
        df_copy = df.copy()
        df_copy['gene_set_library'] = gs_name
        df_copy['analysis'] = 'disease_up_genes'
        all_enrichment_combined.append(df_copy)
        df.to_csv(f"{enrichment_dir}/disease_up_{gs_name}.csv", index=False)

# Healthy-up sonuçları
if healthy_results:
    for gs_name, df in healthy_results.items():
        df_copy = df.copy()
        df_copy['gene_set_library'] = gs_name
        df_copy['analysis'] = 'healthy_up_genes'
        all_enrichment_combined.append(df_copy)
        df.to_csv(f"{enrichment_dir}/healthy_up_{gs_name}.csv", index=False)

# Birleşik enrichment tablosu
sig_combined = pd.DataFrame()
if all_enrichment_combined:
    combined_df = pd.concat(all_enrichment_combined, ignore_index=True)
    combined_df.to_csv(f"{OUT}/enrichment_all_combined.csv", index=False)
    
    # Anlamlı sonuçların özeti
    sig_combined = combined_df[combined_df['Adjusted P-value'] < 0.05].sort_values('Adjusted P-value')
    sig_combined.to_csv(f"{OUT}/enrichment_significant_only.csv", index=False)
    print(f"  Toplam anlamlı terim (p_adj < 0.05): {len(sig_combined)}")

# Top sonuçları göster
if len(sig_combined) > 0:
    print("\n  Top 20 Anlamlı Enrichment Terimi:")
    for i, row in sig_combined.head(20).iterrows():
        print(f"    [{row['analysis']}] {row['gene_set_library']}: {row['Term'][:60]} (p_adj={row['Adjusted P-value']:.2e})")
else:
    print("\n  Anlamlı enrichment terimi bulunamadı (p_adj < 0.05)")
    print("  NOT: 20 genlik küçük bir panel ile enrichment anlamlılığı sınırlı olabilir.")
    print("  Bu durum Discussion'da belirtilecektir.")

# Gen listelerini kaydet
pd.DataFrame({'gene_symbol': gene_symbols_20}).to_csv(f"{OUT}/gene_list_all20.txt", index=False, header=False)
pd.DataFrame({'gene_symbol': disease_genes}).to_csv(f"{OUT}/gene_list_disease_up.txt", index=False, header=False)
pd.DataFrame({'gene_symbol': healthy_genes}).to_csv(f"{OUT}/gene_list_healthy_up.txt", index=False, header=False)

print("\n=== TAMAMLANDI ===")
print(f"Sonuçlar: {OUT}")
