#!/usr/bin/env python3
"""
Figure 3: SHAP Feature Importance (Top 20 genes)
Panelli figür: (A) SHAP Bar Plot, (B) Permutation Importance
Frontiers uyumlu: 300 dpi, min 8pt text, RGB, no title
"""
import numpy as np
import pandas as pd
import json
import zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica'],
    'font.size': 9,
    'axes.labelsize': 10,
    'axes.titlesize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'lines.linewidth': 2.0,
    'axes.linewidth': 1.2,
    'figure.dpi': 300,
    'savefig.dpi': 300,
})

BASE = "/home/ubuntu/upload_extracted/ml_results_v5_final/ml_results_v5"

# ===== DATA LOADING =====
# Gene annotation (ENSEMBL -> Symbol)
with zipfile.ZipFile(f"{BASE}/gene_enrichment_results.zip") as z:
    with z.open('gene_annotation_enrichment_results/table_for_paper_75genes.csv') as f:
        genes = pd.read_csv(f)

# Create mapping
gene_map = {}
for _, row in genes.iterrows():
    ens = row['ENSEMBL ID']
    sym = row['Gene Symbol']
    if pd.notna(sym):
        gene_map[ens] = sym
    else:
        gene_map[ens] = ens  # fallback to ENSEMBL ID

# SHAP importance
shap = pd.read_csv(f"{BASE}/csv/shap_feature_importance.csv")
shap['gene_symbol'] = shap['feature'].map(gene_map).fillna(shap['feature'])
top20_shap = shap.head(20).copy()

# Permutation importance
pi = pd.read_csv(f"{BASE}/csv/permutation_importance_selected.csv")
pi['gene_symbol'] = pi['feature'].map(gene_map).fillna(pi['feature'])
top15_pi = pi.head(15).copy()

# ===== FIGURE (2 panel) =====
fig, axes = plt.subplots(1, 2, figsize=(7.08, 4.5))
plt.subplots_adjust(wspace=0.55, left=0.15, right=0.97, top=0.95, bottom=0.08)

# Color by direction
colors_shap = ['#E74C3C' if d == 'Disease_up' else '#2E86C1' for d in top20_shap['direction']]

# ----- (A) SHAP Importance -----
ax = axes[0]
y_pos = range(len(top20_shap)-1, -1, -1)
bars = ax.barh(list(y_pos), top20_shap['shap_importance'].values, color=colors_shap, edgecolor='white', height=0.7)
ax.set_yticks(list(y_pos))
ax.set_yticklabels(top20_shap['gene_symbol'].values, fontsize=8)
ax.set_xlabel('Mean |SHAP Value|')
ax.set_xlim([0, top20_shap['shap_importance'].max() * 1.15])

# Legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor='#E74C3C', label='Disease-associated'),
                   Patch(facecolor='#2E86C1', label='Healthy-associated')]
ax.legend(handles=legend_elements, loc='lower right', frameon=True, framealpha=0.9, edgecolor='gray')
ax.text(-0.25, 1.03, '(A)', transform=ax.transAxes, fontsize=12, fontweight='bold')

# ----- (B) Permutation Importance -----
ax = axes[1]
colors_pi = ['#E74C3C' if gene_map.get(f, '') in [gene_map.get(s, '') for s in shap[shap['direction']=='Disease_up']['feature'].values] else '#2E86C1' for f in top15_pi['feature']]
# Simpler: map direction from shap
pi_direction = {}
for _, row in shap.iterrows():
    pi_direction[row['feature']] = row['direction']
colors_pi = ['#E74C3C' if pi_direction.get(f, 'Disease_up') == 'Disease_up' else '#2E86C1' for f in top15_pi['feature']]

y_pos2 = range(len(top15_pi)-1, -1, -1)
ax.barh(list(y_pos2), top15_pi['importance_mean'].values, 
        xerr=top15_pi['importance_std'].values, color=colors_pi, edgecolor='white', 
        height=0.7, capsize=2, error_kw={'linewidth': 1.0})
ax.set_yticks(list(y_pos2))
ax.set_yticklabels(top15_pi['gene_symbol'].values, fontsize=8)
ax.set_xlabel('Permutation Importance')
ax.set_xlim([0, (top15_pi['importance_mean'] + top15_pi['importance_std']).max() * 1.15])
ax.legend(handles=legend_elements, loc='lower right', frameon=True, framealpha=0.9, edgecolor='gray')
ax.text(-0.25, 1.03, '(B)', transform=ax.transAxes, fontsize=12, fontweight='bold')

# Save
for fmt in ['png', 'tiff']:
    fig.savefig(f'/home/ubuntu/Figure_3_SHAP.{fmt}', dpi=300, bbox_inches='tight', format=fmt)

from PIL import Image
img = Image.open('/home/ubuntu/Figure_3_SHAP.png').convert('RGB')
img.save('/home/ubuntu/Figure_3_SHAP.jpg', 'JPEG', quality=95, dpi=(300, 300))

print("Figure 3 saved: PNG, TIFF, JPG")
print(f"\nTop 5 SHAP genes: {top20_shap['gene_symbol'].head(5).tolist()}")
print(f"Top 5 Permutation genes: {top15_pi['gene_symbol'].head(5).tolist()}")
