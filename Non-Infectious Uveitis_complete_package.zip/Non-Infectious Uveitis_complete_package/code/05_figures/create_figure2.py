#!/usr/bin/env python3
"""
Figure 2: Statistical Validation (2-panel)
(A) Permutation Test, (B) Feature Ablation
Frontiers uyumlu: 300 dpi, min 8pt text, min 2pt lines, RGB, no title
"""
import numpy as np
import pandas as pd
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica'],
    'font.size': 9,
    'axes.labelsize': 10,
    'axes.titlesize': 10,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'lines.linewidth': 2.0,
    'axes.linewidth': 1.2,
    'figure.dpi': 300,
    'savefig.dpi': 300,
})

BASE = "/home/ubuntu/upload_extracted/ml_results_v5_final/ml_results_v5"

# ===== DATA LOADING =====
perm_scores = np.load(f"{BASE}/plot_data/permutation_scores.npy")
perm_data = json.load(open(f"{BASE}/csv/permutation_test.json"))
real_score = perm_data['real_score']
p_value = perm_data['p_value']

ablation = pd.read_csv(f"{BASE}/csv/ablation_results.csv")

# ===== FIGURE (2 panel) =====
fig, axes = plt.subplots(1, 2, figsize=(7.08, 3.0))
plt.subplots_adjust(wspace=0.35, left=0.08, right=0.97, top=0.90, bottom=0.18)

# ----- (A) Permutation Test -----
ax = axes[0]
ax.hist(perm_scores, bins=25, color='#B0C4DE', edgecolor='#4682B4', alpha=0.85, linewidth=0.8)
ax.axvline(real_score, color='#DC143C', linewidth=2.5, linestyle='-')
ax.set_xlabel('Permutation AUC Score')
ax.set_ylabel('Frequency')
ax.text(0.97, 0.95, f'Actual AUC = {real_score:.3f}\np = {p_value:.3f}',
        transform=ax.transAxes, fontsize=9, fontweight='bold', ha='right', va='top',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='lightyellow', edgecolor='gray', alpha=0.9))
ax.text(-0.12, 1.06, '(A)', transform=ax.transAxes, fontsize=12, fontweight='bold')

# ----- (B) Feature Ablation -----
ax = axes[1]
ax.plot(ablation['n_features'], ablation['cv_auc'], 'o-', color='#2E86C1', markersize=5, label='CV AUC')
ax.plot(ablation['n_features'], ablation['test_auc'], 's--', color='#E74C3C', markersize=5, label='Test AUC')
ax.axvline(75, color='#27AE60', linewidth=1.5, linestyle=':', alpha=0.8, label='Selected (k=75)')
ax.set_xlabel('Number of Features (k)')
ax.set_ylabel('AUC')
ax.set_ylim([0.82, 1.02])
ax.legend(loc='lower right', frameon=True, framealpha=0.9, edgecolor='gray')
ax.text(-0.12, 1.06, '(B)', transform=ax.transAxes, fontsize=12, fontweight='bold')

# Save
for fmt in ['png', 'tiff']:
    fig.savefig(f'/home/ubuntu/Figure_2_v2.{fmt}', dpi=300, bbox_inches='tight', format=fmt)

# JPG
from PIL import Image
img = Image.open('/home/ubuntu/Figure_2_v2.png').convert('RGB')
img.save('/home/ubuntu/Figure_2_v2.jpg', 'JPEG', quality=95, dpi=(300, 300))

print("Figure 2 (v2, 2-panel) saved: PNG, TIFF, JPG")
