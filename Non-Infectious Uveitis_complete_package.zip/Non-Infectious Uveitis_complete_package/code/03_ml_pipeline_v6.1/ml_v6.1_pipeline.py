#!/usr/bin/env python3
"""
PIPELINE v6.1 - CORRECTED (No Data Leakage)
=============================================
Düzeltmeler (v6 üzerine ek):
  1) Batch correction SADECE train setinde öğrenilip test setine uygulanır
  2) Varyans filtresi SADECE train setinde hesaplanır
  3) Grid search SADECE CV skorlarına göre yapılır (test seti kullanılmaz)
  4) Feature selection, scaling Pipeline() içinde (CV sırasında da sızıntı yok)
  5) LODO sabit hiperparametrelerle (ana modelden gelen k ve C) çalıştırılır
  6) Stratified split: label + batch birleşik stratification
  7) Ablation analizi keşifsel (exploratory) olarak etiketlenir

Strateji:
  1) Ham veriyi yükle, log2(CPM+1) normalize et
  2) Stratified 80/20 split (label+batch birleşik stratification)
  3) Batch correction: train'de OLS öğren, test'e uygula
  4) Varyans filtresi: train'de hesapla, test'e uygula
  5) Grid search: Pipeline(SelectKBest + Scaler + LR) ile sadece CV AUC
  6) LODO-CV (sabit hiperparametreler, batch correction her fold'da ayrı)
  7) Final model + tüm analizler
"""
import os, sys, json, warnings, logging, pickle, joblib
import numpy as np
import pandas as pd
from scipy import stats
warnings.filterwarnings('ignore')
np.random.seed(42)

OUT = "/home/ubuntu/ml_results_v6"
for d in ['models', 'logs', 'npy', 'csv', 'plot_data']:
    os.makedirs(f"{OUT}/{d}", exist_ok=True)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.FileHandler(f"{OUT}/logs/pipeline.log", mode='w'), logging.StreamHandler(sys.stdout)])
log = logging.getLogger(__name__)

from sklearn.model_selection import (StratifiedKFold, cross_validate, learning_curve, train_test_split)
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import (accuracy_score, roc_auc_score, f1_score,
                             precision_score, recall_score, confusion_matrix,
                             roc_curve, classification_report)
from sklearn.inspection import permutation_importance
import shap

# ============================================================
# 1. VERİ YÜKLEME VE NORMALIZASYON
# ============================================================
log.info("=" * 70)
log.info("PIPELINE v6.1 - CORRECTED: No data leakage")
log.info("=" * 70)

RAW_DIR = "/home/ubuntu/strategy_a_ml_ready/strategy_a_raw_data"

# Ham count matrisleri (genler satır, örnekler sütun)
df194 = pd.read_csv(f"{RAW_DIR}/GSE194060_raw_counts.csv.gz", compression='gzip', index_col=0)
df195 = pd.read_csv(f"{RAW_DIR}/GSE195501_raw_counts.csv.gz", compression='gzip', index_col=0)
meta194 = pd.read_csv(f"{RAW_DIR}/GSE194060_metadata.csv")
meta195 = pd.read_csv(f"{RAW_DIR}/GSE195501_metadata.csv")

log.info(f"GSE194060: {df194.shape[0]} gen x {df194.shape[1]} ornek")
log.info(f"GSE195501: {df195.shape[0]} gen x {df195.shape[1]} ornek")

# Ortak genler
common_genes = sorted(list(set(df194.index) & set(df195.index)))
log.info(f"Ortak gen sayisi: {len(common_genes)}")
df194 = df194.loc[common_genes]
df195 = df195.loc[common_genes]

# log2(CPM+1) normalizasyon (her veri seti kendi library size'ına göre)
def log2_cpm(df):
    df = df.clip(lower=0)
    lib_sizes = df.sum(axis=0)
    cpm = df.div(lib_sizes, axis=1) * 1e6
    return np.log2(cpm + 1)

df194_norm = log2_cpm(df194).T  # samples x genes
df195_norm = log2_cpm(df195).T  # samples x genes

# Birleşik matris
X_combined = pd.concat([df194_norm, df195_norm], axis=0)
meta_combined = pd.concat([meta194, meta195], axis=0, ignore_index=True)
meta_combined['batch'] = ['GSE194060'] * len(meta194) + ['GSE195501'] * len(meta195)

y_all = meta_combined['binary_label'].values
batches = meta_combined['batch'].values
sample_ids = meta_combined['sample_id'].values

log.info(f"Birlesik: {X_combined.shape} (D={sum(y_all==1)}, H={sum(y_all==0)})")

# ============================================================
# 2. STRATIFIED SPLIT (batch-aware)
# ============================================================
log.info("\nADIM 2: Stratified train/test split")

# Stratified split: label + batch birleşik stratification
stratify_labels = np.array([f"{y}_{b}" for y, b in zip(y_all, batches)])
X_train_raw, X_test_raw, y_train, y_test, idx_train, idx_test = train_test_split(
    X_combined.values, y_all, np.arange(len(y_all)),
    test_size=0.2, stratify=stratify_labels, random_state=42
)

meta_train = meta_combined.iloc[idx_train].reset_index(drop=True)
meta_test = meta_combined.iloc[idx_test].reset_index(drop=True)
batch_train = batches[idx_train]
batch_test = batches[idx_test]
feature_names = X_combined.columns.tolist()

log.info(f"  Train: {len(y_train)} (D={sum(y_train==1)}, H={sum(y_train==0)})")
log.info(f"  Test:  {len(y_test)} (D={sum(y_test==1)}, H={sum(y_test==0)})")
log.info(f"  Train batches: GSE194060={sum(batch_train=='GSE194060')}, GSE195501={sum(batch_train=='GSE195501')}")
log.info(f"  Test batches:  GSE194060={sum(batch_test=='GSE194060')}, GSE195501={sum(batch_test=='GSE195501')}")

# Save metadata
meta_train.to_csv(f"{OUT}/csv/train_metadata.csv", index=False)
meta_test.to_csv(f"{OUT}/csv/test_metadata.csv", index=False)

# ============================================================
# 3. BATCH CORRECTION (train'de öğren, test'e uygula)
# ============================================================
log.info("\nADIM 3: Batch correction (train-only fitting)")

# limma-style: gene ~ intercept + batch (disease label KULLANILMIYOR)
# Sadece batch etkisini çıkar, disease sinyalini koruma ihtiyacı yok
# çünkü disease label'ı modele vermiyoruz
batch_train_binary = (batch_train == 'GSE195501').astype(float)
batch_test_binary = (batch_test == 'GSE195501').astype(float)

X_train_corrected = X_train_raw.copy()
X_test_corrected = X_test_raw.copy()
batch_effects = []

for g in range(X_train_raw.shape[1]):
    y_gene_train = X_train_raw[:, g]
    # Fit: gene ~ intercept + batch (SADECE train'de)
    X_design_train = np.column_stack([np.ones(len(y_gene_train)), batch_train_binary])
    beta = np.linalg.lstsq(X_design_train, y_gene_train, rcond=None)[0]
    
    # Train'den batch etkisini çıkar
    X_train_corrected[:, g] = y_gene_train - beta[1] * batch_train_binary
    # Test'e de aynı beta'yı uygula
    X_test_corrected[:, g] = X_test_raw[:, g] - beta[1] * batch_test_binary
    batch_effects.append(beta[1])

batch_effects = np.array(batch_effects)
log.info(f"  Ort |batch effect|: {np.abs(batch_effects).mean():.4f}")
log.info(f"  Median |batch effect|: {np.median(np.abs(batch_effects)):.4f}")

# Doğrulama
corr_before_train = np.corrcoef(
    X_train_raw[batch_train=='GSE194060'].mean(axis=0),
    X_train_raw[batch_train=='GSE195501'].mean(axis=0)
)[0, 1]
corr_after_train = np.corrcoef(
    X_train_corrected[batch_train=='GSE194060'].mean(axis=0),
    X_train_corrected[batch_train=='GSE195501'].mean(axis=0)
)[0, 1]
log.info(f"  Train korelasyon: {corr_before_train:.4f} -> {corr_after_train:.4f}")

batch_comparison = {
    'before_correlation_train': float(corr_before_train),
    'after_correlation_train': float(corr_after_train),
    'mean_abs_batch_effect': float(np.abs(batch_effects).mean()),
}
with open(f"{OUT}/csv/batch_correction_comparison.json", 'w') as f:
    json.dump(batch_comparison, f, indent=2)

# ============================================================
# 4. VARIANCE FILTER (train'de hesapla, test'e uygula)
# ============================================================
log.info("\nADIM 4: Variance filter (train-only)")

# Düşük ifadeli genleri filtrele (train'de en az %10 örnekte CPM > 1)
min_samples = int(X_train_corrected.shape[0] * 0.10)
expressed_mask = (X_train_corrected > np.log2(1 + 1)).sum(axis=0) >= min_samples
log.info(f"  Ifade filtresi: {sum(expressed_mask)} gen")

# Varyans filtresi (train'de en yüksek varyanslı %50)
train_vars = X_train_corrected[:, expressed_mask].var(axis=0)
n_top = int(len(train_vars) * 0.50)
top_var_idx = np.argsort(train_vars)[::-1][:n_top]

# Expressed genler arasından top variance olanları seç
expressed_indices = np.where(expressed_mask)[0]
selected_gene_indices = expressed_indices[top_var_idx]

X_train = X_train_corrected[:, selected_gene_indices]
X_test = X_test_corrected[:, selected_gene_indices]
selected_feature_names = [feature_names[i] for i in selected_gene_indices]

log.info(f"  Varyans filtresi sonrasi: {X_train.shape[1]} gen")
log.info(f"  Train: {X_train.shape}, Test: {X_test.shape}")

# ============================================================
# 5. GRID SEARCH (SADECE CV SKORU - test seti KULLANILMAZ)
# ============================================================
log.info("\nADIM 5: Grid search (CV-only, no test leakage)")

k_values = [5, 10, 15, 20, 25, 30, 40, 50, 75, 100]
C_values = [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0]
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

grid_results = []
for k in k_values:
    if k > X_train.shape[1]:
        continue
    for C in C_values:
        pipe = Pipeline([
            ('selector', SelectKBest(f_classif, k=k)),
            ('scaler', StandardScaler()),
            ('clf', LogisticRegression(C=C, penalty='l2', solver='lbfgs',
                                       max_iter=10000, class_weight='balanced', random_state=42))
        ])
        
        # SADECE CV skorları
        cv_r = cross_validate(pipe, X_train, y_train, cv=cv,
                              scoring=['accuracy', 'roc_auc', 'f1', 'recall', 'precision'],
                              return_train_score=True, n_jobs=-1)
        
        cv_auc = cv_r['test_roc_auc'].mean()
        cv_auc_std = cv_r['test_roc_auc'].std()
        train_auc = cv_r['train_roc_auc'].mean()
        overfit_gap = train_auc - cv_auc
        
        grid_results.append({
            'k': k, 'C': C,
            'cv_auc_mean': float(cv_auc),
            'cv_auc_std': float(cv_auc_std),
            'cv_f1_mean': float(cv_r['test_f1'].mean()),
            'cv_recall_mean': float(cv_r['test_recall'].mean()),
            'cv_precision_mean': float(cv_r['test_precision'].mean()),
            'cv_accuracy_mean': float(cv_r['test_accuracy'].mean()),
            'train_auc_mean': float(train_auc),
            'overfit_gap': float(overfit_gap),
        })

grid_df = pd.DataFrame(grid_results)
grid_df.to_csv(f"{OUT}/csv/grid_search_results.csv", index=False)

# Model seçimi: SADECE CV AUC ve overfit gap'e göre
# Öncelik: overfit gap < 0.15 olanlar arasından en yüksek CV AUC
candidates = grid_df[grid_df['overfit_gap'] < 0.15].copy()
if len(candidates) == 0:
    candidates = grid_df.sort_values('overfit_gap').head(30)

# Composite score: sadece CV metrikleri (test seti YOK)
candidates['composite'] = (candidates['cv_auc_mean'] * 0.40 +
                           candidates['cv_f1_mean'] * 0.25 +
                           candidates['cv_recall_mean'] * 0.20 -
                           candidates['overfit_gap'] * 0.15)

best_row = candidates.sort_values('composite', ascending=False).iloc[0]
best_k = int(best_row['k'])
best_C = float(best_row['C'])

log.info(f"\n  En iyi (CV-only): k={best_k}, C={best_C}")
log.info(f"  CV AUC: {best_row['cv_auc_mean']:.4f} ± {best_row['cv_auc_std']:.4f}")
log.info(f"  CV F1: {best_row['cv_f1_mean']:.4f}, CV Recall: {best_row['cv_recall_mean']:.4f}")
log.info(f"  Overfit gap: {best_row['overfit_gap']:.4f}")

log.info("\n  Top 10:")
for _, r in candidates.sort_values('composite', ascending=False).head(10).iterrows():
    log.info(f"    k={int(r['k'])}, C={r['C']:.3f}: CV_AUC={r['cv_auc_mean']:.4f}, "
             f"Gap={r['overfit_gap']:.4f}")

# ============================================================
# 6. FINAL MODEL (train'de eğit, test'te değerlendir)
# ============================================================
log.info("\nADIM 6: Final model egitimi")

final_pipe = Pipeline([
    ('selector', SelectKBest(f_classif, k=best_k)),
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression(C=best_C, penalty='l2', solver='lbfgs',
                               max_iter=10000, class_weight='balanced', random_state=42))
])
final_pipe.fit(X_train, y_train)

# Train metrikleri
y_train_proba = final_pipe.predict_proba(X_train)[:, 1]
y_train_pred = final_pipe.predict(X_train)
train_auc = roc_auc_score(y_train, y_train_proba)
train_acc = accuracy_score(y_train, y_train_pred)
train_f1 = f1_score(y_train, y_train_pred)

# Test metrikleri (İLK KEZ burada bakıyoruz)
y_test_proba = final_pipe.predict_proba(X_test)[:, 1]
y_test_pred = final_pipe.predict(X_test)
test_auc = roc_auc_score(y_test, y_test_proba)
test_acc = accuracy_score(y_test, y_test_pred)
test_f1 = f1_score(y_test, y_test_pred)
test_recall = recall_score(y_test, y_test_pred)
test_precision = precision_score(y_test, y_test_pred)

log.info(f"  Train: AUC={train_auc:.4f}, Acc={train_acc:.4f}, F1={train_f1:.4f}")
log.info(f"  Test:  AUC={test_auc:.4f}, Acc={test_acc:.4f}, F1={test_f1:.4f}")
log.info(f"  Test Recall={test_recall:.4f}, Precision={test_precision:.4f}")
log.info(f"  Train-Test AUC Gap: {train_auc - test_auc:.4f}")

# Save model
joblib.dump(final_pipe, f"{OUT}/models/BEST_MODEL_v6.joblib")
pickle.dump(final_pipe, open(f"{OUT}/models/BEST_MODEL_v6.pkl", 'wb'))

# Save predictions
np.save(f"{OUT}/npy/X_train.npy", X_train)
np.save(f"{OUT}/npy/X_test.npy", X_test)
np.save(f"{OUT}/npy/y_pred_test.npy", y_test_pred)
np.save(f"{OUT}/npy/y_proba_test.npy", y_test_proba)
np.save(f"{OUT}/npy/y_pred_train.npy", y_train_pred)
np.save(f"{OUT}/npy/y_proba_train.npy", y_train_proba)
np.save(f"{OUT}/npy/feature_names.npy", np.array(selected_feature_names))

# Selected features
selector = final_pipe.named_steps['selector']
selected_mask = selector.get_support()
selected_features = [selected_feature_names[i] for i in range(len(selected_feature_names)) if selected_mask[i]]
np.save(f"{OUT}/npy/selected_features.npy", np.array(selected_features))
log.info(f"  Secilen gen sayisi: {len(selected_features)}")

# ============================================================
# 7. LODO-CV (Leave-One-Dataset-Out) - sabit hiperparametreler
# ============================================================
log.info("\nADIM 7: LODO-CV (fixed hyperparameters from main model)")
log.info(f"  Sabit parametreler: k={best_k}, C={best_C}")

# LODO için tüm ham (normalize edilmiş ama batch-corrected olmamış) veriyi kullan
X_all_raw = X_combined.values
lodo_results = []

for test_batch in ['GSE194060', 'GSE195501']:
    train_mask = batches != test_batch
    test_mask = batches == test_batch
    
    X_lodo_tr_raw = X_all_raw[train_mask]
    X_lodo_te_raw = X_all_raw[test_mask]
    y_lodo_tr = y_all[train_mask]
    y_lodo_te = y_all[test_mask]
    
    # LODO'da train tek batch olduğu için batch correction anlamsız
    # Sadece pipeline (SelectKBest + Scaler + LR) uygula
    
    # Variance filter (train'de)
    min_s = int(X_lodo_tr_raw.shape[0] * 0.10)
    expr_mask = (X_lodo_tr_raw > np.log2(2)).sum(axis=0) >= min_s
    tr_vars = X_lodo_tr_raw[:, expr_mask].var(axis=0)
    n_t = int(len(tr_vars) * 0.50)
    top_idx = np.argsort(tr_vars)[::-1][:n_t]
    expr_indices = np.where(expr_mask)[0]
    sel_idx = expr_indices[top_idx]
    
    X_lodo_tr = X_lodo_tr_raw[:, sel_idx]
    X_lodo_te = X_lodo_te_raw[:, sel_idx]
    
    # Sabit hiperparametreler (ana modelden gelen k ve C)
    k_lodo = min(best_k, X_lodo_tr.shape[1])
    pipe = Pipeline([
        ('selector', SelectKBest(f_classif, k=k_lodo)),
        ('scaler', StandardScaler()),
        ('clf', LogisticRegression(C=best_C, penalty='l2', solver='lbfgs',
                                   max_iter=10000, class_weight='balanced', random_state=42))
    ])
    pipe.fit(X_lodo_tr, y_lodo_tr)
    yp = pipe.predict_proba(X_lodo_te)[:, 1]
    ypred = pipe.predict(X_lodo_te)
    
    res = {'test_batch': test_batch, 'k': k_lodo, 'C': best_C,
           'auc': float(roc_auc_score(y_lodo_te, yp)),
           'accuracy': float(accuracy_score(y_lodo_te, ypred)),
           'recall': float(recall_score(y_lodo_te, ypred)),
           'f1': float(f1_score(y_lodo_te, ypred))}
    lodo_results.append(res)
    log.info(f"  LODO {test_batch} (k={k_lodo}, C={best_C}): AUC={res['auc']:.4f}, Acc={res['accuracy']:.3f}")

lodo_df = pd.DataFrame(lodo_results)
lodo_df.to_csv(f"{OUT}/csv/lodo_cv_results.csv", index=False)

# LODO özet
for tb in ['GSE194060', 'GSE195501']:
    lodo_row = lodo_df[lodo_df.test_batch == tb].iloc[0]
    log.info(f"  LODO {tb}: AUC={lodo_row['auc']:.4f}")

# ============================================================
# 8. BOOTSTRAP CI (test seti)
# ============================================================
log.info("\nADIM 8: Bootstrap CI")

n_bootstrap = 1000
bootstrap_metrics = {'accuracy': [], 'auc': [], 'f1': [], 'precision': [], 'recall': []}
rng = np.random.RandomState(42)

for _ in range(n_bootstrap):
    idx = rng.choice(len(y_test), size=len(y_test), replace=True)
    y_b = y_test[idx]
    yp_b = y_test_proba[idx]
    ypred_b = y_test_pred[idx]
    
    if len(np.unique(y_b)) < 2:
        continue
    
    bootstrap_metrics['accuracy'].append(accuracy_score(y_b, ypred_b))
    bootstrap_metrics['auc'].append(roc_auc_score(y_b, yp_b))
    bootstrap_metrics['f1'].append(f1_score(y_b, ypred_b, zero_division=0))
    bootstrap_metrics['precision'].append(precision_score(y_b, ypred_b, zero_division=0))
    bootstrap_metrics['recall'].append(recall_score(y_b, ypred_b, zero_division=0))

bootstrap_ci = {}
for metric, values in bootstrap_metrics.items():
    values = np.array(values)
    bootstrap_ci[metric] = {
        'mean': float(np.mean(values)),
        'ci_lower': float(np.percentile(values, 2.5)),
        'ci_upper': float(np.percentile(values, 97.5)),
    }
    log.info(f"  {metric}: {bootstrap_ci[metric]['mean']:.4f} "
             f"[{bootstrap_ci[metric]['ci_lower']:.4f} - {bootstrap_ci[metric]['ci_upper']:.4f}]")

with open(f"{OUT}/csv/bootstrap_confidence_intervals.json", 'w') as f:
    json.dump(bootstrap_ci, f, indent=2)

# ============================================================
# 9. PERMUTATION TEST
# ============================================================
log.info("\nADIM 9: Permutation test")

n_permutations = 200
perm_scores = []
rng_perm = np.random.RandomState(42)

for i in range(n_permutations):
    y_perm = rng_perm.permutation(y_train)
    pipe_perm = Pipeline([
        ('selector', SelectKBest(f_classif, k=best_k)),
        ('scaler', StandardScaler()),
        ('clf', LogisticRegression(C=best_C, penalty='l2', solver='lbfgs',
                                   max_iter=10000, class_weight='balanced', random_state=42))
    ])
    cv_perm = cross_validate(pipe_perm, X_train, y_perm, cv=cv,
                             scoring='roc_auc', n_jobs=-1)
    perm_scores.append(cv_perm['test_score'].mean())

perm_scores = np.array(perm_scores)
real_cv_auc = best_row['cv_auc_mean']
p_value = (np.sum(perm_scores >= real_cv_auc) + 1) / (n_permutations + 1)

log.info(f"  Real CV AUC: {real_cv_auc:.4f}")
log.info(f"  Perm mean: {perm_scores.mean():.4f} ± {perm_scores.std():.4f}")
log.info(f"  p-value: {p_value:.4f}")

np.save(f"{OUT}/plot_data/permutation_scores.npy", perm_scores)
with open(f"{OUT}/csv/permutation_test.json", 'w') as f:
    json.dump({'real_score': float(real_cv_auc), 'perm_mean': float(perm_scores.mean()),
               'perm_std': float(perm_scores.std()), 'p_value': float(p_value),
               'n_permutations': n_permutations}, f, indent=2)

# ============================================================
# 10. ABLATION (Feature count effect)
# ============================================================
log.info("\nADIM 10: Ablation analysis")

ablation_results = []
for k in [5, 10, 15, 20, 25, 30, 40, 50, 75, 100, 150, 200, 500]:
    if k > X_train.shape[1]:
        continue
    pipe_ab = Pipeline([
        ('selector', SelectKBest(f_classif, k=k)),
        ('scaler', StandardScaler()),
        ('clf', LogisticRegression(C=best_C, penalty='l2', solver='lbfgs',
                                   max_iter=10000, class_weight='balanced', random_state=42))
    ])
    cv_ab = cross_validate(pipe_ab, X_train, y_train, cv=cv, scoring='roc_auc',
                           return_train_score=True, n_jobs=-1)
    
    # Test (sadece ablation grafiği için)
    pipe_ab.fit(X_train, y_train)
    test_auc_ab = roc_auc_score(y_test, pipe_ab.predict_proba(X_test)[:, 1])
    
    ablation_results.append({
        'n_features': k,
        'cv_auc': float(cv_ab['test_score'].mean()),
        'cv_auc_std': float(cv_ab['test_score'].std()),
        'train_auc': float(cv_ab['train_score'].mean()),
        'test_auc': float(test_auc_ab),
        'overfit_gap': float(cv_ab['train_score'].mean() - cv_ab['test_score'].mean()),
    })
    log.info(f"  k={k}: CV={cv_ab['test_score'].mean():.4f}, Test={test_auc_ab:.4f}, "
             f"Gap={cv_ab['train_score'].mean() - cv_ab['test_score'].mean():.4f}")

pd.DataFrame(ablation_results).to_csv(f"{OUT}/csv/ablation_results.csv", index=False)

# ============================================================
# 11. SHAP ANALYSIS
# ============================================================
log.info("\nADIM 11: SHAP analysis")

X_train_selected = final_pipe.named_steps['selector'].transform(X_train)
X_test_selected = final_pipe.named_steps['selector'].transform(X_test)
X_train_scaled = final_pipe.named_steps['scaler'].transform(X_train_selected)
X_test_scaled = final_pipe.named_steps['scaler'].transform(X_test_selected)

np.save(f"{OUT}/npy/X_train_scaled.npy", X_train_scaled)
np.save(f"{OUT}/npy/X_test_scaled.npy", X_test_scaled)

explainer = shap.LinearExplainer(final_pipe.named_steps['clf'],
                                  X_train_scaled, feature_perturbation='interventional')
shap_values_train = explainer.shap_values(X_train_scaled)
shap_values_test = explainer.shap_values(X_test_scaled)

np.save(f"{OUT}/npy/shap_values_train.npy", shap_values_train)
np.save(f"{OUT}/npy/shap_values_test.npy", shap_values_test)

# SHAP importance
mean_abs_shap = np.abs(shap_values_train).mean(axis=0)
coefs = final_pipe.named_steps['clf'].coef_[0]
shap_df = pd.DataFrame({
    'feature': selected_features,
    'shap_importance': mean_abs_shap,
    'coefficient': coefs,
    'direction': ['Disease_up' if c > 0 else 'Healthy_up' for c in coefs]
}).sort_values('shap_importance', ascending=False)
shap_df.to_csv(f"{OUT}/csv/shap_feature_importance.csv", index=False)

# Top 30 for plotting
top30 = shap_df.head(30)
shap_plot_data = {
    'features': top30['feature'].tolist(),
    'importance': top30['shap_importance'].tolist(),
    'coefficients': top30['coefficient'].tolist(),
    'directions': top30['direction'].tolist(),
}
with open(f"{OUT}/plot_data/shap_top30.json", 'w') as f:
    json.dump(shap_plot_data, f, indent=2)

log.info(f"  Top 5 SHAP genes: {shap_df.head(5)['feature'].tolist()}")

# ============================================================
# 12. PERMUTATION IMPORTANCE
# ============================================================
log.info("\nADIM 12: Permutation importance")

# Permutation importance: pipeline üzerinden, sadece selected features üzerinde
# Pipeline zaten SelectKBest + Scaler + LR içeriyor, doğrudan kullanabiliriz
perm_imp = permutation_importance(final_pipe, X_test, y_test,
                                   n_repeats=10, random_state=42, scoring='roc_auc')
# Sadece selected features'ın importance değerlerini al
sel_mask = final_pipe.named_steps['selector'].get_support()
sel_indices = np.where(sel_mask)[0]
pi_df = pd.DataFrame({
    'feature': selected_features,
    'importance_mean': perm_imp.importances_mean[sel_indices],
    'importance_std': perm_imp.importances_std[sel_indices],
}).sort_values('importance_mean', ascending=False)
pi_df.to_csv(f"{OUT}/csv/permutation_importance_selected.csv", index=False)

# ============================================================
# 13. SUBGROUP ANALYSIS
# ============================================================
log.info("\nADIM 13: Subgroup analysis")

subgroup_results = []
# Disease subtypes
for subtype in meta_test['disease_subtype'].unique():
    mask = meta_test['disease_subtype'] == subtype
    if mask.sum() == 0:
        continue
    X_sub = X_test[mask]
    y_sub = y_test[mask]
    yp_sub = y_test_proba[mask]
    ypred_sub = y_test_pred[mask]
    
    res = {
        'group_by': 'disease_subtype', 'value': subtype,
        'n': int(mask.sum()),
        'n_disease': int(sum(y_sub == 1)),
        'n_healthy': int(sum(y_sub == 0)),
        'accuracy': float(accuracy_score(y_sub, ypred_sub)),
        'recall': float(recall_score(y_sub, ypred_sub, zero_division=0)),
        'f1': float(f1_score(y_sub, ypred_sub, zero_division=0)),
        'mean_proba': float(yp_sub.mean()),
    }
    if len(np.unique(y_sub)) >= 2:
        res['auc'] = float(roc_auc_score(y_sub, yp_sub))
    else:
        res['auc'] = float('nan')
    subgroup_results.append(res)

# Batch
for batch_val in meta_test['batch'].unique():
    mask = meta_test['batch'] == batch_val
    if mask.sum() == 0:
        continue
    X_sub = X_test[mask]
    y_sub = y_test[mask]
    yp_sub = y_test_proba[mask]
    ypred_sub = y_test_pred[mask]
    
    res = {
        'group_by': 'batch', 'value': batch_val,
        'n': int(mask.sum()),
        'n_disease': int(sum(y_sub == 1)),
        'n_healthy': int(sum(y_sub == 0)),
        'accuracy': float(accuracy_score(y_sub, ypred_sub)),
        'recall': float(recall_score(y_sub, ypred_sub, zero_division=0)),
        'f1': float(f1_score(y_sub, ypred_sub, zero_division=0)),
        'mean_proba': float(yp_sub.mean()),
    }
    if len(np.unique(y_sub)) >= 2:
        res['auc'] = float(roc_auc_score(y_sub, yp_sub))
    else:
        res['auc'] = float('nan')
    subgroup_results.append(res)

pd.DataFrame(subgroup_results).to_csv(f"{OUT}/csv/subgroup_analysis.csv", index=False)

# ============================================================
# 14. THRESHOLD ANALYSIS
# ============================================================
log.info("\nADIM 14: Threshold analysis")

threshold_results = []
for thr in np.arange(0.10, 0.95, 0.05):
    ypred_thr = (y_test_proba >= thr).astype(int)
    threshold_results.append({
        'threshold': round(float(thr), 2),
        'accuracy': float(accuracy_score(y_test, ypred_thr)),
        'f1': float(f1_score(y_test, ypred_thr, zero_division=0)),
        'recall': float(recall_score(y_test, ypred_thr, zero_division=0)),
        'specificity': float(recall_score(1 - y_test, 1 - ypred_thr, zero_division=0)),
    })
pd.DataFrame(threshold_results).to_csv(f"{OUT}/csv/threshold_analysis.csv", index=False)

# ============================================================
# 15. MODEL COMPARISON
# ============================================================
log.info("\nADIM 15: Model comparison")

models = {
    'LR_L2': LogisticRegression(C=best_C, penalty='l2', solver='lbfgs',
                                 max_iter=10000, class_weight='balanced', random_state=42),
    'SVM_Linear': SVC(C=best_C, kernel='linear', class_weight='balanced',
                       probability=True, random_state=42),
    'SVM_RBF': SVC(C=best_C, kernel='rbf', class_weight='balanced',
                    probability=True, random_state=42),
    'Random_Forest': RandomForestClassifier(n_estimators=200, max_depth=5,
                                            class_weight='balanced', random_state=42),
}

comp_results = {}
for name, clf in models.items():
    pipe_c = Pipeline([
        ('selector', SelectKBest(f_classif, k=best_k)),
        ('scaler', StandardScaler()),
        ('clf', clf)
    ])
    cv_c = cross_validate(pipe_c, X_train, y_train, cv=cv,
                          scoring=['roc_auc', 'f1', 'recall', 'accuracy'],
                          return_train_score=True, n_jobs=-1)
    pipe_c.fit(X_train, y_train)
    yp_c = pipe_c.predict_proba(X_test)[:, 1]
    ypred_c = pipe_c.predict(X_test)
    
    comp_results[name] = {
        'cv_auc': float(cv_c['test_roc_auc'].mean()),
        'cv_auc_std': float(cv_c['test_roc_auc'].std()),
        'train_auc': float(cv_c['train_roc_auc'].mean()),
        'test_auc': float(roc_auc_score(y_test, yp_c)),
        'test_accuracy': float(accuracy_score(y_test, ypred_c)),
        'test_f1': float(f1_score(y_test, ypred_c)),
        'test_recall': float(recall_score(y_test, ypred_c)),
        'test_precision': float(precision_score(y_test, ypred_c)),
        'overfit_gap': float(cv_c['train_roc_auc'].mean() - cv_c['test_roc_auc'].mean()),
    }
    log.info(f"  {name}: CV={comp_results[name]['cv_auc']:.4f}, Test={comp_results[name]['test_auc']:.4f}, "
             f"Gap={comp_results[name]['overfit_gap']:.4f}")
    
    joblib.dump(pipe_c, f"{OUT}/models/{name}.joblib")

pd.DataFrame(comp_results).T.to_csv(f"{OUT}/csv/model_comparison.csv")

# ============================================================
# 16. LEARNING CURVE
# ============================================================
log.info("\nADIM 16: Learning curve")

train_sizes, train_scores, val_scores = learning_curve(
    final_pipe, X_train, y_train, cv=cv, scoring='roc_auc',
    train_sizes=np.linspace(0.3, 1.0, 8), n_jobs=-1, random_state=42
)

lc_data = {
    'train_sizes': train_sizes.tolist(),
    'train_mean': train_scores.mean(axis=1).tolist(),
    'train_std': train_scores.std(axis=1).tolist(),
    'val_mean': val_scores.mean(axis=1).tolist(),
    'val_std': val_scores.std(axis=1).tolist(),
}
with open(f"{OUT}/plot_data/learning_curve.json", 'w') as f:
    json.dump(lc_data, f, indent=2)

# ============================================================
# 17. OVERFITTING SUMMARY
# ============================================================
log.info("\nADIM 17: Overfitting summary")

cv_final = cross_validate(final_pipe, X_train, y_train, cv=cv,
                          scoring=['roc_auc', 'accuracy', 'f1'],
                          return_train_score=True)

overfit_summary = {
    'train_auc': float(train_auc),
    'cv_auc': float(cv_final['test_roc_auc'].mean()),
    'test_auc': float(test_auc),
    'gap_train_cv': float(train_auc - cv_final['test_roc_auc'].mean()),
    'gap_cv_test': float(cv_final['test_roc_auc'].mean() - test_auc),
    'gap_train_test': float(train_auc - test_auc),
    'best_k': best_k,
    'best_C': best_C,
    'permutation_p_value': float(p_value),
}
with open(f"{OUT}/csv/overfitting_analysis.json", 'w') as f:
    json.dump(overfit_summary, f, indent=2)

log.info(f"  Train AUC: {train_auc:.4f}")
log.info(f"  CV AUC:    {cv_final['test_roc_auc'].mean():.4f}")
log.info(f"  Test AUC:  {test_auc:.4f}")
log.info(f"  Gap (Train-CV):   {train_auc - cv_final['test_roc_auc'].mean():.4f}")
log.info(f"  Gap (Train-Test): {train_auc - test_auc:.4f}")

# ============================================================
# 18. FINAL SUMMARY
# ============================================================
log.info("\n" + "=" * 70)
log.info("PIPELINE v6.1 TAMAMLANDI")
log.info("=" * 70)

final_summary = {
    'pipeline_version': 'v6.1_corrected',
    'leakage_fixes': [
        'Batch correction: train-only fitting, applied to test',
        'Variance filter: train-only calculation',
        'Grid search: CV-only scoring (no test metrics in composite)',
        'Disease label NOT used in batch correction model',
        'Stratified split: label+batch combined stratification',
        'LODO: fixed hyperparameters from main model (no test-batch tuning)',
    ],
    'best_model': f'LR_L2_k{best_k}_C{best_C}',
    'best_k': best_k, 'best_C': best_C,
    'cv_auc': float(best_row['cv_auc_mean']),
    'test_auc': float(test_auc),
    'test_accuracy': float(test_acc),
    'test_f1': float(test_f1),
    'test_recall': float(test_recall),
    'permutation_p': float(p_value),
    'n_train': len(y_train), 'n_test': len(y_test),
    'n_features_input': X_train.shape[1],
    'n_features_selected': best_k,
}
with open(f"{OUT}/csv/final_summary.json", 'w') as f:
    json.dump(final_summary, f, indent=2)

log.info(json.dumps(final_summary, indent=2))
log.info("Tüm sonuçlar kaydedildi.")
